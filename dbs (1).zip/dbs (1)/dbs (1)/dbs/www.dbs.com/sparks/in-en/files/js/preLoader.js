var preloader = setTimeout(loading, 500);
var icon = '';
var newIcon = '';
function loading() {
    $('#loader .showbox').css('display','block');
}