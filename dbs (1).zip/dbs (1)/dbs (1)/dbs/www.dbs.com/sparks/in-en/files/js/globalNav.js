 // ========================================================================================================================
// Header & Footer

//Hide show progress bar
if($('body').attr('data-progressBar')){
    if($('body').attr('data-progressBar') == 'false') {
        $('header .progressBar').remove();
        Waypoint.refreshAll()
    }
    $(window).on('scroll', function(){
        var winheight = window.innerHeight;
        var docheight = document.body.clientHeight;
        var scrollTop = $(document).scrollTop()
        var trackLength = docheight - winheight
        var pctScrolled = Math.floor(scrollTop/trackLength * 100) // gets percentage scrolled (ie: 80 NaN if tracklength == 0)
        TweenMax.to($('header .progressBar > div'), 0.1, {width: pctScrolled+'%', ease:Linear.easeNone});
    })
} else {
    $('header .progressBar').remove();
}

//At page
    //Level 2
if($('body').attr('data-atPageLevel2')){
    navNo = parseInt($('body').attr('data-atPageLevel2')) + 1;
    $('.mainNav .right #nav-'+navNo+'').addClass('atPage');
}
    //Level 3
if($('body').attr('data-atPageLevel3')){
    navLevel2No = parseInt($('body').attr('data-atPageLevel2')) + 2;
    navLevel3No = parseInt($('body').attr('data-atPageLevel3')) + 1;
    $('.btmNavWrap .btmNavEach:nth-of-type('+(navLevel2No)+')').find('.navWrap a:nth-of-type('+(navLevel3No)+')').addClass('atPage');
} else {
    navLevel2No = parseInt($('body').attr('data-atPageLevel2')) + 2;
    navLevel3No = 1;
    $('.btmNavWrap .btmNavEach:nth-of-type('+(navLevel2No)+')').find('.navWrap a:nth-of-type('+(navLevel3No)+')').addClass('atPage');
}

    // Explore Dbs
pageTitle = ($('.titleBtn').html().split('<svg')[0]).trim();
$('.exploreNav .navWrap p:contains('+pageTitle+')').parents('a').addClass('atPage');

// STOP START SCROLL
////////////////////////////////////////////////
var leftoffsetY;
var scrollStop = $('html').hasClass('noScroll');

function stopScroll() {
    if(!scrollStop) {
        leftoffsetY = window.pageYOffset;
        var topY = -leftoffsetY + 'px';
        $('html').addClass('noScroll');
        $('body').css({'top':topY});
        scrollStop = true;
    }
}

function startScroll() {
    if(scrollStop) {
        $('html').removeClass('noScroll');
        $('html, body').scrollTop(leftoffsetY);
        scrollStop = false;
    }
}

$.fn.hasScrollBar = function() {
    return this.outerHeight() >= $(window).outerHeight();
}


//Header Effects
function caroChgHeader(e) {
    var target = e.target;
    var total = e.item.count;
    var i = e.item.index;
    var pageI = e.page.index;
    var pageSize = e.page.count;
    var totalItem = $(target).find('.owl-item:visible').length;

    if(i<0){
        i=0;
    }

    $(target).parents('.navOwlWrap').find('.owlNavBtn').css('display','block');

    if(i+1 <= 1){
        $(target).parents('.navOwlWrap').find('.btnLeft').css('display','none');
    }

    if (pageI+1 === pageSize && pageI >= 0) {
        $(target).parents('.navOwlWrap').find('.btnRight').css('display','none');
    }
}

var owlExplore = $('.owlExplore');

function startCarousel(){
    $('.navWrap').addClass('owl-carousel');
    owlExplore.owlCarousel({
        stagePadding: 0,
        margin: 20,
        autoWidth:true,
        onInitialized: caroChgHeader
    });

    $(owlExplore.siblings('.btnRight')).click(function(){
        owlExplore.trigger('next.owl.carousel');
    })
    $(owlExplore.siblings('.btnLeft')).click(function(){
        owlExplore.trigger('prev.owl.carousel');
    })
    owlExplore.on('changed.owl.carousel', function(e) {
        caroChgHeader(e);
    })

    $('.owlSubLevel').each(function() {
        var owlSubLevel = $(this);
        owlSubLevel.owlCarousel({
            stagePadding: 0,
            margin: 20,
            autoWidth:true,
            onInitialized: caroChgHeader
        });

        $(owlSubLevel.siblings('.btnRight')).click(function(){
            owlSubLevel.trigger('next.owl.carousel');
        })
        $(owlSubLevel.siblings('.btnLeft')).click(function(){
            owlSubLevel.trigger('prev.owl.carousel');
        })

        owlSubLevel.on('changed.owl.carousel', function(e) {
            caroChgHeader(e);
        })
    });
}

function stopCarousel() {
    var headerOwl = $('header .owl-carousel');
    headerOwl.trigger('destroy.owl.carousel');
    headerOwl.removeClass('owl-carousel');
}

function chkCaro() {
    if (minLG()) {
      startCarousel();
    } else {
      stopCarousel();
    }
}

chkCaro();

function chkExceed() {

    $('.navWrap').each(function() {
        outer = $(this).find('.owl-stage-outer').width();
        inner = $(this).find('.owl-stage').width()-20;

        if(outer <= inner) {
            $(this).parent('.navOwlWrap').addClass('exceed');
        } else {
            $(this).parent('.navOwlWrap').removeClass('exceed');
        }
    });
}

chkExceed();

$(window).resize(function() {
    chkCaro();
    chkExceed();
});

//only width
var width = $(window).width();
$(window).on('resize', function(e) {
    if($(this).width() != width){
        resetAllNav();
        startScroll();
        $('header .burgBtn, header .titleBtn').removeClass('menuOpen');
        width = $(this).width();
    }
});


// Close Nav
function resetAllNav() {
    TweenMax.to('header .progressBar', 0.4, {height:3, ease: Power4.easeOut});

    colorChange('black');
    closeBtmNav();

    if(minLG()){
        closeTopNav();
        $('header .burgBtn, header .titleBtn').removeClass('menuOpen');
    } else {
        closeTopNavMob();
    }
}

function closeTopNav() {
    TweenMax.staggerTo('header .topNavWrap > div:not(.mainNav):visible > div > *', 0.2, {opacity:0, rotationX:'90'}, 0.05, complete);
    function complete() {
        TweenMax.set('header .topNavWrap *',{clearProps:"all"});
        $('header .topNavWrap > *').css('display','none');

        TweenMax.set('.mainNav > div > *',{opacity:0, x:'-30px'});
        $('.mainNav').css('display','flex');

        TweenMax.staggerTo('.mainNav > div > *', 0.2, {opacity:1, x:'0px'}, 0.05);
    }
}

function closeTopNavMob() {
    $('header').css('bottom','auto');
    TweenMax.to('.topNavWrap > div:not(.mainNav)', 0.4, {height:'0px', ease: Power4.easeOut});
}

function closeBtmNav() {
    $('header .mainNav .right a').removeClass('opened');
    TweenMax.to('.btmNavWrap > div', 0.4, {height:'0px', ease: Power4.easeOut});
    TweenMax.to($('.mainNav .right span'), 0.3, {y:'100%', opacity: 0, ease: Power4.easeOut});
}
// end Close Nav

// Transition Nav
function openTopNav(from,to) {
    TweenMax.to('header .progressBar', 0.4, {height:0, ease: Power4.easeOut});
    TweenMax.staggerTo(from + ' > div > *', 0.2, {rotationX:'90'}, 0.05, complete);
    function complete() {
        TweenMax.set('header .topNavWrap *',{clearProps:"all"});
        $('header .topNavWrap > *').css('display','none');

        TweenMax.set(to + ' > div > *',{x:'-30px', rotationX:'90'});
        $(to).css('display','flex');

        TweenMax.staggerTo(to + ' > div > *', 0.2, {x:'0px', rotationX:'0'}, 0.05);

        //search auto focus
        $('.searchFormDesk input').focus().val("");
    }
}

function openTopNavMob(openThis) {
    TweenMax.to('header .progressBar', 0.4, {height:0, ease: Power4.easeOut});
    $(openThis).css('display','block');
    h = $(openThis).children('div.left').outerHeight();
    TweenMax.to(openThis, 0.6, {height:h, ease: Power4.easeOut});
    TweenMax.set(openThis + ' > div.left > *',{x:'-30px', rotationX:'90'});
    TweenMax.staggerTo(openThis + ' > div.left > *', 0.2, {x:'0px', rotationX:'0'}, 0.05);
}

function openBtmNav(openThis) {
    TweenMax.to('header .progressBar', 0.4, {height:0, ease: Power4.easeOut});
    $(openThis).each(function() {
        TweenMax.set('.btmNavWrap > div', {height:'0px'});
        h = $(this).children('div').outerHeight();

        TweenMax.to($(this), 0.6, {height:h, ease: Power4.easeOut, onComplete: function(){
            if($('header').hasScrollBar() && maxSM()){
                $('header').css('bottom','0');
            }
        }});
    });

    //TweenMax.set('.btmNavWrap .navWrap a', {opacity:'0'});
    // TweenMax.staggerTo(openThis+' .navWrap a', 0.4, {x:'0px'}, 0.1);
}

function colorChange(color) {
    if(color == "white"){
        TweenMax.to($('.headerWrap, .mainNav, .searchNav, .countryNav'), 0.3, {backgroundColor:'#F2F2F2', ease: Power4.easeOut});
        TweenMax.to($('.burgBtn > div'), 0.3, {backgroundColor:'#000000', ease: Power4.easeOut});
        TweenMax.to($('header .mainNav *'), 0.3, {color:'#000000', ease: Power4.easeOut});
        TweenMax.to($('.pathWhite'), 0.3, {fill:'#000000', ease: Power4.easeOut});
    } else {
        TweenMax.to($('.headerWrap, .mainNav, .searchNav, .countryNav'), 0.3, {backgroundColor:'#000000', ease: Power4.easeOut});
        TweenMax.to($('.burgBtn > div'), 0.3, {backgroundColor:'#F2F2F2', ease: Power4.easeOut});
        TweenMax.to($('header .mainNav *'), 0.3, {color:'#F2F2F2', ease: Power4.easeOut});
        TweenMax.to($('.pathWhite'), 0.3, {fill:'#F2F2F2', ease: Power4.easeOut});
    }
}

// end Transition Nav

$('header .searchBtn').click(function(){
    openTopNav('.mainNav','.searchNav');
    closeBtmNav();
});

$('header .closeBtn').click(function(){
    resetAllNav();
    startScroll();
});

$('header .titleBtn').click(function(){

    if(minLG()) {
        //remove scroll
        openTopNav('.mainNav','.countryNav');
        openBtmNav('.exploreNav');
    } else {
        //mobile
        $(this).toggleClass('menuOpen');
        if($(this).hasClass('menuOpen')){
            //remove scroll
            stopScroll();
            //close burger navs
            $('header .burgBtn').addClass('menuOpen');
            resetAllNav();
            //Open title nav
            openTopNavMob('.countryNav');
            openBtmNav('.exploreNav');

            TweenMax.to($('.titleBtn svg'), 0.2, {y:'100%', opacity: 0, ease: Power4.easeIn, onComplete: function(){
                TweenMax.set($('.titleBtn svg'),{y:'100%', opacity: 0, rotation: 180});
                TweenMax.to($('.titleBtn svg'), 0.2, {y:'0%', opacity: 1, ease: Power4.easeOut});
            }});

        } else {
            //close
            TweenMax.to($('.titleBtn svg'), 0.2, {y:'-100%', opacity: 0, ease: Power4.easeIn, onComplete: function(){
                TweenMax.set($('.titleBtn svg'),{y:'-100%', opacity: 0, rotation: 0});
                TweenMax.to($('.titleBtn svg'), 0.2, {y:'0%', opacity: 1, ease: Power4.easeOut});
            }});
            startScroll();
            $('header .burgBtn').removeClass('menuOpen');
            resetAllNav();
        }
    }
});

$('header .titleBtn').hover(
    function() {
        if(minLG()){
            TweenMax.to($('.titleBtn svg'), 0.3, {y:'100%', opacity: 0, ease: Power4.easeIn, onComplete: function(){
                TweenMax.set($('.titleBtn svg'),{y:'-100%', opacity: 0});
                TweenMax.to($('.titleBtn svg'), 0.6, {y:'0%', opacity: 1, ease: Power4.easeOut});
            }});
        }
    }, function() {
        TweenMax.to($('.titleBtn svg'), 0.2, {y:'0%', ease: Power4.easeOut});
    }
);

$('header .burgBtn').click(function(){
    //mobile
    $(this).toggleClass('menuOpen');
    if($(this).hasClass('menuOpen')){
        //remove scroll
        stopScroll();
        //close title navs
        if($('header .titleBtn').hasClass('menuOpen')){
            TweenMax.to($('.titleBtn svg'), 0.2, {y:'-100%', opacity: 0, ease: Power4.easeIn, onComplete: function(){
                TweenMax.set($('.titleBtn svg'),{y:'-100%', opacity: 0, rotation: 0});
                TweenMax.to($('.titleBtn svg'), 0.2, {y:'0%', opacity: 1, ease: Power4.easeOut});
            }});
        }
        $('header .titleBtn').removeClass('menuOpen');
        resetAllNav();
        //open burger nav
        openTopNavMob('.searchNav');
        openBtmNav('.btmNavEach');
        openBtmNav('.langMob');
        //change color
        colorChange('white');
    } else {
        //close
        startScroll();
        resetAllNav();
    }
});

var timeout;
// Hover In Each A
$(document).on('mouseenter', "header .mainNav .right a:not(.searchBtn):not(.opened)", function() {
    if(minLG()){
        navNo = parseInt($(this).attr('id').split('nav-')[1]);
        thisSub = '.btmNavEach[data-subOf="nav-'+navNo+'"]';

        if($.isNumeric(navNo) && $(thisSub).length){

            clearTimeout(timeout);

            $('header .mainNav .right a:not(.searchBtn)').removeClass('opened');
            $(this).addClass('opened');

            TweenMax.to($('.mainNav .right span'), 0.3, {y:'100%', opacity: 0, ease: Power4.easeOut});
            TweenMax.to($(this).find('span'), 0.3, {y:'0%', opacity: 1, ease: Power4.easeOut});
            openBtmNav(thisSub);
        }

        thisMainNav = $(this);
        clearTimeout(timeoutMainNav);
        TweenMax.to($('header .mainNav a p'), 0.4, {opacity:0.6, ease: Power4.easeOut});
        TweenMax.to($(this).children('p'), 0.4, {opacity:1, ease: Power4.easeOut});
    }

});

// Still inside
$(document).on('mouseenter', 'header .mainNav .right a.opened, header .btmNavEach', function() {
    if(minLG()){
        clearTimeout(timeout);
    }
});

// Hover Out
$(document).on('mouseleave', 'header .mainNav .right a.opened, header .btmNavEach', function() {
    if(minLG()){
        timeout = setTimeout(function(){
            resetAllNav();
        }, 100);
    }
});

$('header .btmNavWrap').bind('mouseleave', function() {
    if(minLG()){
        timeout = setTimeout(function(){
            TweenMax.to($('header .mainNav a p'), 0.4, {opacity:0.6, ease: Power4.easeOut});
            TweenMax.to($('header .mainNav a.atPage p'), 0.4, {opacity:1, ease: Power4.easeOut});
        }, 100);
    }
});

// Main Nav Hovering
var timeoutMainNav;
var thisMainNav;

$('header .mainNav .right a:not(.searchBtn)').hover(
    function() {
        if(minLG()){
            thisMainNav = $(this);
            clearTimeout(timeoutMainNav);
            TweenMax.to($('header .mainNav a p'), 0.4, {opacity:0.6, ease: Power4.easeOut});
            TweenMax.to($(this).children('p'), 0.4, {opacity:1, ease: Power4.easeOut});
        }
    }, function() {
        if(minLG()){
            timeoutMainNav = setTimeout(function(){
                if(thisMainNav.find('span').css('opacity') <= 0){
                    TweenMax.to($('header .mainNav a p'), 0.4, {opacity:0.6, ease: Power4.easeOut});
                    TweenMax.to($('header .mainNav a.atPage p'), 0.4, {opacity:1, ease: Power4.easeOut});
                }
            }, 100);
        }
    }
);

$('header .mainNav .left a.langBtn').hover(
    function() {
        if(minLG()){
            TweenMax.to($(this).children('p'), 0.4, {opacity:1, ease: Power4.easeOut});
        }
    }, function() {
        if(minLG()){
            TweenMax.to($('header .mainNav .left a.langBtn p'), 0.4, {opacity:0.6, ease: Power4.easeOut});
        }
    }
);

// Country Nav Hoverin
var timeoutCountryNav;
$('header .countryNav .left a').hover(
    function() {
        if(minLG()){
            clearTimeout(timeoutCountryNav);
            TweenMax.to($('header .countryNav .left a'), 0.4, {opacity:0.4, ease: Power4.easeOut});
            TweenMax.to($(this), 0.4, {opacity:1, ease: Power4.easeOut});
        }
    }, function() {
        timeoutCountryNav = setTimeout(function(){
            TweenMax.to($('header .countryNav .left a'), 0.4, {opacity:0.4, ease: Power4.easeOut});
            TweenMax.to($('header .countryNav .left a.atPage'), 0.4, {opacity:1, ease: Power4.easeOut});
        }, 100);
    }
);

// Explore Nav Hoverin
var timeoutExploreNav;
$('header .exploreNav .navWrap a').hover(
    function() {
        if(minLG()){
            clearTimeout(timeoutExploreNav);
            TweenMax.to($('header .exploreNav .navWrap a'), 0.4, {opacity:0.6, ease: Power4.easeOut});
            TweenMax.to($(this), 0.4, {opacity:1, ease: Power4.easeOut});
        }
    }, function() {
        timeoutExploreNav = setTimeout(function(){
            TweenMax.to($('header .exploreNav .navWrap a'), 0.4, {opacity:0.6, ease: Power4.easeOut});
            TweenMax.to($('header .exploreNav .navWrap a.atPage'), 0.4, {opacity:1, ease: Power4.easeOut});
        }, 100);
    }
);

// Explore Nav Hoverin
var timeoutBtmEachNav;
$('header .btmNavEach .navWrap a').hover(
    function() {
        if(minLG()){
            clearTimeout(timeoutBtmEachNav);
            TweenMax.to($('header .btmNavEach .navWrap a p'), 0.4, {color:'#000000', ease: Power4.easeOut});
            TweenMax.to($(this).find('p'), 0.4, {color:'#CC0000', ease: Power4.easeOut});

            TweenMax.to($('header .btmNavEach .navWrap a .imgWrap'), 0.4, {boxShadow:'0 1px 1px rgba(0,0,0,0), 0 1px 1px rgba(0,0,0,0)', ease: Power4.easeOut});
            TweenMax.to($(this).find('.imgWrap'), 0.4, {boxShadow:'0 4px 4px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.2)', ease: Power4.easeOut});
        }
    }, function() {
        timeoutBtmEachNav = setTimeout(function(){
            TweenMax.to($('header .btmNavEach .navWrap a p'), 0.4, {color:'#000000', ease: Power4.easeOut});
            TweenMax.to($('header .btmNavEach .navWrap a.atPage p'), 0.4, {color:'#CC0000', ease: Power4.easeOut});

            TweenMax.to($('header .btmNavEach .navWrap a .imgWrap'), 0.4, {boxShadow:'0 1px 1px rgba(0,0,0,0), 0 1px 1px rgba(0,0,0,0)', ease: Power4.easeOut});
            TweenMax.to($('header .btmNavEach .navWrap a.atPage .imgWrap'), 0.4, {boxShadow:'0 4px 4px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.2)', ease: Power4.easeOut});
        }, 100);
    }
);

// All Solo Nav Hoverin
var thisSoloNav;

$('header .closeBtn, header .searchFormDesk input[type=image]').hover(
    function() {
        if(minLG()){
            thisSoloNav = $(this)
            TweenMax.to(thisSoloNav, 0.4, {opacity:1, ease: Power4.easeOut});
        }
    }, function() {
            TweenMax.to(thisSoloNav, 0.4, {opacity:0.6, ease: Power4.easeOut});
    }
);

$('header .searchBtn').hover(
    function() {
        if(minLG()){
            thisSoloNav = $(this).find('img')
            TweenMax.to(thisSoloNav, 0.4, {opacity:1, ease: Power4.easeOut});
        }
    }, function() {
            TweenMax.to(thisSoloNav, 0.4, {opacity:0.6, ease: Power4.easeOut});
    }
);

//double tap
$('header .mainNav .right a:not(.searchBtn):not(.opened)').on('click', function (e) {
    if (!(e.isDefaultPrevented() || e.metaKey || e.ctrlKey)) {
        //e.preventDefault();
        
        
        if(minLG()){
            navNo = parseInt($(this).attr('id').split('nav-')[1]);
            thisSub = '.btmNavEach[data-subOf="nav-'+navNo+'"]';
            if(!$(thisSub).length){
                //no sub navi
                if (this.getAttribute("href") != null) {window.location.href = this.getAttribute("href");}
            } else {
                //else have sub navi
                if ($(thisSub).height() > 0){
                    if (this.getAttribute("href") != null) {window.location.href = this.getAttribute("href");}
                }
            }
        }
        return false;
    }
});

// end Header & Footer
// ========================================================================================================================


 // ========================================================================================================================
// Social


if($('.social').length > 0){

    $('main').waypoint({
        handler: function(dir) {
            if(dir == 'down' && !ie()){
                //TweenMax.to(('header'), 0.7, {y: '-122px', ease: Power4.easeInOut});
            } else {
                $('.social, .spotify').css('display','block');
                TweenMax.to($('.social, .spotify'), 0.7, {opacity: '1', ease: Power4.easeInOut});
            }
            if(dir == 'down') {
                TweenMax.to($('.social, .spotify'), 0.7, {opacity: '0', ease: Power4.easeInOut, onComplete: function(){
                    $('.social, .spotify').css('display','none');
                }});
            }
        },
        offset: 'bottom-in-view'
    });

    //Social
          var toggleBtn = false;
          $('.socialBtn').click(function(){
              if(!toggleBtn){
                  toggleBtn = true;
                  $(this).addClass('toggle');
                  $('.social a:not(.socialBtn)').css('display','block');
                  // TweenMax.set($('.social a.socialBtn'),{scale: 0.6, opacity: 0});
                  $('.socialBtn').css("background-image", "url(files/media/header/closeWhite.png)");
                  TweenMax.from($('.social a.socialBtn'), 0.3, {scale: 0.2, ease: Power1.easeOut});
                  TweenMax.to($('.social a'), 0.1, {'margin-bottom': '0', scale: 1, ease: Power1.easeOut});

                  if(maxLG()){
                      stopScroll();
                  }

              } else {
                  closeSocial();
              }
          })

          function closeSocial(){
              if(toggleBtn){
                  toggleBtn = false;
                  $('.socialBtn').removeClass('toggle');
                  $('.socialBtn').css("background-image", "url(files/media/header/s_share_white.svg)");
                  TweenMax.to($('.social a:not(:last-child)'), 0.1, {'margin-bottom': '-60px', ease: Power1.easeOut});
                  TweenMax.from($('.social a.socialBtn'), 0.3, {scale: 0.2, ease: Power1.easeOut});
                  setTimeout(function(){$('.social a:not(.socialBtn)').css('display','none');}, 400);
                  startScroll();
              }
          }

          if($('.copylink').length) {
              new ClipboardJS('.copylink');
          }

          function copied(){
              $('.copylink').on('click', function(e) {
                  $('body').prepend('<div class="copied" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.3); z-index: 9999;"><img style="background-color: rgba(0,0,0,0.8); border-radius: 50px; padding: 10px; width: 50px; position: absolute; top: 50%; left: 50%; margin-top: -25px; margin-top: -25px; margin-left: -25px;" src="files/media/header/s_copy_white.svg"</div>');
                  TweenMax.to($('.copied'), 0.5, {'opacity': '0', delay: 0.5, ease: Power1.easeOut, onComplete:function(){
                      $('.copied').remove();
                  }});
              });
          }
          copied();
      };

// end Social
// ========================================================================================================================

$(document).on('click touchend', function(e) {
    if(scrollStop){
        var header = $("header");
        var social = $(".social");
        if (!header.is(e.target) && header.has(e.target).length === 0 && !social.is(e.target) && social.has(e.target).length === 0){
            resetAllNav();
            startScroll();
            $('header .burgBtn, header .titleBtn').removeClass('menuOpen');
            width = $(this).width();
            if($('.social').length > 0){
                closeSocial();
            }
        }
    }
});
