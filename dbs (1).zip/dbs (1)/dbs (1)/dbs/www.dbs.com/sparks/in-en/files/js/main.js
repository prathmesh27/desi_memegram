// ========================================================================================================================
// my set Up

if (!Array.prototype.find) {
  Object.defineProperty(Array.prototype, 'find', {
    value: function(predicate) {
     // 1. Let O be ? ToObject(this value).
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }

      var o = Object(this);

      // 2. Let len be ? ToLength(? Get(O, "length")).
      var len = o.length >>> 0;

      // 3. If IsCallable(predicate) is false, throw a TypeError exception.
      if (typeof predicate !== 'function') {
        throw new TypeError('predicate must be a function');
      }

      // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
      var thisArg = arguments[1];

      // 5. Let k be 0.
      var k = 0;

      // 6. Repeat, while k < len
      while (k < len) {
        // a. Let Pk be ! ToString(k).
        // b. Let kValue be ? Get(O, Pk).
        // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
        // d. If testResult is true, return kValue.
        var kValue = o[k];
        if (predicate.call(thisArg, kValue, k, o)) {
          return kValue;
        }
        // e. Increase k by 1.
        k++;
      }

      // 7. Return undefined.
      return undefined;
    },
    configurable: true,
    writable: true
  });
}

var timedDoneLoad;

function loadTooLong() {
  $('#loader .showbox').css('display','block');
}
setTimeout(loadTooLong, 2000);

function doneLoad() {
  $('#loader').remove();
  $('html').css('overflow-y', 'auto');
  clearTimeout(timedDoneLoad);

  if($('[data-src="#popUp"]').length) {
      $('[data-src="#popUp"]').trigger( "click" );
  }
}

$('main > section:first-of-type').on('load', function(){
  doneLoad();
});

$(window).on('load', function(){
  doneLoad();
});

//Safari Back Reload
window.onpageshow = function(event) {if (event.persisted) {window.location.reload();}};
//Detect Responsive
function smartDevice() {return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);}
function ie() {if (document.documentMode || /Edge/.test(navigator.userAgent)) {return true;} else {return false;}}
function maxXS() {return Modernizr.mq('(max-width: 360px)');}
function maxSM() {return Modernizr.mq('(max-width: 480px)');}
function maxMD() {return Modernizr.mq('(max-width: 768px)');}
function maxLG() {return Modernizr.mq('(max-width: 1024px)');}
function minXS() {return Modernizr.mq('(min-width: 361px)');}
function minSM() {return Modernizr.mq('(min-width: 481px)');}
function minMD() {return Modernizr.mq('(min-width: 769px)');}
function minLG() {return Modernizr.mq('(min-width: 1025px)');}

// end my Set Up
// ========================================================================================================================

// ========================================================================================================================


var allSeasons = getAllSeasons();
function getAllSeasons(){
    var result = null;
    $.ajax({
        async: false,
        url: "files/allEpisodes.json",
        dataType: "json",
    }).done(function(data) {
      result = data;
    });
    return result;
}

var resizeW = $(window).width();
$(window).resize(function() {
    Waypoint.refreshAll();
    if($(this).width() != resizeW){
      resizeW = $(this).width();
      resizeHandler();
    }
});

function resizeHandler() {
    allFully();
    Waypoint.refreshAll();
};


// run fully
function allFully() {
  $('.fullyMusical').fully({offset: $('header').outerHeight()*2});
  $('.eachEpisodeFully').fully({offset: $('header').outerHeight()*3});
};

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

if($('.backTopBtn').length > 0) {
    $('.backTopBtn').click(function(){
        $('html, body').animate({
            scrollTop: 0
        }, 1000);
        return false;
    })
}

if($('.layout-btmBar').length) {
    if(!Cookies.getJSON('visit')) {
        Cookies.set('visit', { home: 0, about: 0}, { expires: 1 });
    }

    if($('.homeBar').length) {
        if(Cookies.getJSON('visit').home > 0){
           homeBarVisitCount = Cookies.getJSON('visit').home;
            if(homeBarVisitCount < 3) {
                Cookies.set('visit', { home: (homeBarVisitCount + 1), about: Cookies.getJSON('visit').about}, { expires: 1 });
            } else {
                removeBtmBar();
            }
        } else {
            Cookies.set('visit', { home: 1, about: Cookies.getJSON('visit').about}, { expires: 1 });
        }

        function removeBtmBar() {
            Cookies.set('closedBtmBar', true, { expires: 1 });

            TweenMax.to($('.layout-btmBar'), 0.3, {opacity:'0', ease: Power2.easeOut, onComplete:function(){
                $('.layout-btmBar').remove();
            }});
        };

        $('.layout-btmBar .closeBtn').click(function(){
            removeBtmBar();
        });

        $('.layout-btmBar .goToPlaylist').click(function(){
            $("html,body").animate({scrollTop: $('.layout-audioPlayer').position().top}, 1000);
            removeBtmBar();
        });

        if(Cookies.get('closedBtmBar')){
            $('.layout-btmBar').remove();
        };
    }
}

//Youtube
$(document).ready(function () {
  var youtubeId = getUrlParameter('v');
  if(youtubeId != null && youtubeId != true && youtubeId != '') {
      openYoutube(youtubeId);
  }
});

function closeVideos() {
    startScroll();
    $('.layout-youtube').remove();
    Waypoint.refreshAll();
}

function openYoutube(youtubeId) {
    $('body').append('\
        <section class="layout-youtube">\
            <p class="closeBtn"><img src="files/media/leftBackBtnWhite.svg"/></p>\
            <iframe class="youtube" src="https://www.youtube.com/embed/'+youtubeId+'?rel=0&autoplay=1&showinfo=1&controls=1&playsinline=1&enablejsapi=1" frameborder="0" allowfullscreen"></iframe>\
        </section>\
    ');
}

$('body').on('click', '.openYoutube', function() {
    youtubeId = $(this).attr('data-youtube');
    openYoutube(youtubeId);
});

$('body').on('click', '.closeBtn', function() {
    closeVideos();
});

if($('.season2Listing').length) {
    $.each( allSeasons.season2, function( i, value ) {
        $('.season2Listing').append('\
            <div class="lg-4 md-6 sm-12 eachCard">\
                <a href="'+allSeasons.season2[i].url+'" class="wrap">\
                  <div class="imgWrap bgImgWrapCen bgImgHoverZoom">\
                    <div class="bgImg" style="background-image: url('+allSeasons.season2[i].thumbImg+');"></div>\
                  </div>\
                  <div class="textBox">\
                    <h6>Episode '+allSeasons.season2[i].episode+' | '+allSeasons.season2[i].dur+'</h6>\
                    <h3 class="biggerh3">'+allSeasons.season2[i].title+'</h3>\
                    <h5>'+allSeasons.season2[i].longDesc+'</h5>\
                  </div>\
                </a>\
            </div>\
        ')
    });
}

if($('.season1Listing').length) {
    $.each( allSeasons.season1.reverse(), function( i, value ) {
        $('.season1Listing').prepend('\
            <div class="lg-4 md-6 sm-12 eachCard">\
                <a class="openNextPlayer wrap" data-youtube="'+allSeasons.season1[i].id+'">\
                  <div class="imgWrap bgImgWrapCen bgImgHoverZoom">\
                    <div class="bgImg" style="background-image: url('+allSeasons.season1[i].thumbImg+');"></div>\
                  </div>\
                  <div class="textBox">\
                    <h6>Episode '+allSeasons.season1[i].episode+' | '+allSeasons.season1[i].dur+'</h6>\
                    <h3 class="biggerh3">'+allSeasons.season1[i].title+'</h3>\
                    <h5>'+allSeasons.season1[i].desc+'</h5>\
                  </div>\
                </a>\
            </div>\
        ')
    });
}

if($('.season1OwlListing').length) {
    $.each(allSeasons.season1, function( i, value ) {
        $('.season1OwlListing').append('\
            <a class="eachSeason1 openNextPlayer" data-youtube="'+allSeasons.season1[i].id+'">\
              <div class="bgImgWrapCen bgImgHoverZoom">\
                <div class="bgImg" style="background-image: url('+allSeasons.season1[i].thumbImg+');"></div>\
                <h4>'+allSeasons.season1[i].episode+'</h4>\
              </div>\
            </a>\
        ')
    });

    var owlSeason1 = $('.owlSeason1');
    owlSeason1.owlCarousel({
        stagePadding: 50,
        margin: 20,
        items: 1,
        responsive: {
            481 : {
                stagePadding: 50,
                margin: 20,
                items: 3,
            },
            1025 : {
                stagePadding: 50,
                margin: 20,
                items: 5,
            }
        }
    });
}

if($('.owlSeason2Listing').length) {
    $.each(allSeasons.season2, function( i, value ) {
        console.log('f');
        $('.owlSeason2Listing').append('\
            <div class="eachEpisode eachEpisodeFully bgImgWrapCen">\
              <div class="bgImg md-hide" style="background-image: url('+allSeasons.season2[i].mainImg+');"></div>\
              <div class="bgImg md-show" style="background-image: url('+allSeasons.season2[i].mainImgMob+');"></div>\
              <div class="bgImgGradLeft"></div>\
              <div class="textBox">\
                <h1>'+allSeasons.season2[i].title+'</h1>\
                <p><em>Episode '+allSeasons.season2[i].episode+' | '+allSeasons.season2[i].dur+'</em></p>\
                <h5>'+allSeasons.season2[i].desc+'</h5>\
                <a class="redBtn ripple" href="'+allSeasons.season2[i].url+'">Learn more</a>\
              </div>\
            </div>\
        ')






    });

    var owlEpisodes = $('.owlEpisodes');

    owlEpisodes.owlCarousel({
        stagePadding: 0,
        margin: 0,
        items: 1,
        loop: true,
        responsive: {
            1025 : {
                stagePadding: 130,
                margin: 20,
                items: 1,
            }
        }
    });

    $('.owlSideNav .sideBtn.prev').click(function(){
        owlEpisodes.trigger('prev.owl.carousel');
    });

    $('.owlSideNav .sideBtn.next').click(function(){
        owlEpisodes.trigger('next.owl.carousel');
    });
}

function updateEpisodePauseTimeCookies(episodeId, pausedTime) {
    Cookies.set(episodeId, pausedTime, { expires: 1 });
}

function getEpisodePausedTime(episodeId) {
    if (typeof(Cookies.getJSON(episodeId)) != 'undefined' && typeof(episodeId) != 'undefined'){
        if(Cookies.getJSON(episodeId) == 0) {
            return -1;
        } else {
            return Cookies.getJSON(episodeId);
        }

    } else {
        return 0;
    }
}

if($('.openNextPlayer').length) {

    //PLAYER JS
    var nextPlayer;
    var episodeId;
    var nextPlayerOpened = false;
    var thisSeason;
    var myStepCheck;

    //DYNAMIC EPISODE TOP FOLD
    if($('body').attr('data-season2-episode')){
        thisEpisode = allSeasons.season2.find(function(x) {
            return x.episode === parseInt($('body').attr('data-season2-episode'));
        });
        $('.layout-season2TopFold .episodeTitle').html(thisEpisode.title);
        $('.layout-season2TopFold .episodeNo').html(thisEpisode.episode);
        $('.layout-season2TopFold .episodeDur').html(thisEpisode.dur);
        $('.layout-season2TopFold .episodeDesc').html(thisEpisode.desc);
        $('.layout-season2TopFold .episodeBtn').attr('data-youtube',thisEpisode.id);

        $('.layout-season2TopFold .bgImg.md-hide').css('background-image','url('+thisEpisode.mainImg+')');
        $('.layout-season2TopFold .bgImg.md-show').css('background-image','url('+thisEpisode.mainImgMob+')');


        //check if video already played before
        if(getEpisodePausedTime(thisEpisode.id) > 0) {
            //update episode btn
            // with episode number
            // $('.episodeBtn').html('Resume episode '+thisEpisode.episode+'')
            // new changes below
            $('.episodeBtn').html('Continue Watching ')
        } else if (getEpisodePausedTime(thisEpisode.id) == -1) {
            //update episode btn
            $('.episodeBtn').html('Replay episode '+thisEpisode.episode+'')
        }
    }




    var finishSeason2 = false;
    function findNextEpisode(curEpisodeNo) {
        nextEpisode = allSeasons[thisSeason].find(function(x) {
            return x.episode === curEpisodeNo + 1;
        });

        if (typeof nextEpisode == "undefined") {
            if(!finishSeason2) {
              finishSeason2 = true;
            }
            if(thisSeason == 'season2') {
                nextEpisode = allSeasons[thisSeason].find(function(x) {
                    return x.episode === 1;
                });
                return {
                    no: nextEpisode.episode,
                    id: nextEpisode.id,
                    url: nextEpisode.url
                };
            } else {
                return {
                    no: -1,
                    id: -1,
                    url: -1
                };
            }

            // nextEpisode = allSeasons[thisSeason].find(function(x) {
            //     return x.episode === 1;
            // });
        } else {
            if(finishSeason2) {
              thisSeason = 'season1';
            }
            nextEpisode = nextEpisode;
            return {
                no: nextEpisode.episode,
                id: nextEpisode.id,
                url: nextEpisode.url
            };
        }

    }

    function findPreviousEpisode(curEpisodeNo) {
        prevEpisode = allSeasons[thisSeason].find(function(x) {
            return x.episode === curEpisodeNo - 1;
        });
        if (typeof prevEpisode == "undefined") {
            prevEpisode = allSeasons[thisSeason].find(function(x) {
                return x.episode === allSeasons[thisSeason].length;
            });

            if(thisSeason == 'season1') {
                prevEpisode = allSeasons['season2'].find(function(x) {
                    return x.episode === allSeasons['season2'].length;
                });
                return {
                    no: prevEpisode.episode,
                    id: prevEpisode.id,
                    url: prevEpisode.url
                };
            }
        } else {
            prevEpisode = prevEpisode;
        }
        return {
            no: prevEpisode.episode,
            id: prevEpisode.id,
            url: prevEpisode.url
        };
    }

    function openNextPlayer(episodeId) {
        //identify this episode belongs to which season
        $.each(allSeasons, function( i, value ) {
            value.find(function(x) {
                if (x.id === episodeId) {
                    thisSeason = i;
                }
            })
        });

        thisEpisode = allSeasons[thisSeason].find(function(x) {
            return x.id === episodeId;
        });

        //Run findNextEpisode() once only!
        foundNextEpisode = findNextEpisode(thisEpisode.episode);
        foundNextEpisodeNo = foundNextEpisode.no;

        if(foundNextEpisodeNo != -1) {
            $('body').append('\
                <section class="layout-nextPlayer">\
                    <a class="closeNextPlayer"><img src="files/media/leftBackBtnWhite.svg"/></a>\
                    <div class="playNextBtn"><p class="redBtn ripple small nextEpisodeBtn" data-nextEpisode-no='+foundNextEpisodeNo+'>Season <span class="thisSeason">'+thisSeason.split('season')[1]+'</span> Episode <span class="nextEpisodeNo">'+foundNextEpisodeNo+'</span> playing in <span class="countDown">10</span> seconds</p></div>\
                    <iframe id="player" class="youtube" src="https://www.youtube.com/embed/'+episodeId+'?rel=0&autoplay=1&showinfo=1&mute=1&controls=1&playsinline=1" frameborder="0" allowfullscreen></iframe>\
                </section>\
            ');
        } else {
            //if this is last episode from season 1, dont append next button
            $('body').append('\
                <section class="layout-nextPlayer">\
                    <a class="closeNextPlayer"><img src="files/media/leftBackBtnWhite.svg"/></a>\
                    <iframe id="player" class="youtube" src="https://www.youtube.com/embed/'+episodeId+'?rel=0&autoplay=1&showinfo=1&mute=1&controls=1&playsinline=1" frameborder="0" allowfullscreen></iframe>\
                </section>\
            ');
        }


        nextPlayer = new YT.Player('player', {
            events: {
              'onReady': onPlayerReady,
              'onStateChange': onPlayerStateChange
            }
        });

        function stepCheck(timestamp) {
            //update cookie
            if(nextPlayerOpened == true) {
                nextEpisodeNo = parseInt($('.nextEpisodeBtn').attr('data-nextEpisode-no'));
                updateEpisodePauseTimeCookies(findPreviousEpisode(nextEpisodeNo).id, nextPlayer.getCurrentTime());
            }

            //check if video ending for next button
            countDown = parseInt(nextPlayer.getDuration() - nextPlayer.getCurrentTime());
            if(countDown < 10 && countDown > 0) {
                $('.playNextBtn').addClass('active');
                $('.playNextBtn .countDown').html(countDown);
            } else {
                $('.playNextBtn').removeClass('active');
            }

            myStepCheck = window.requestAnimationFrame(stepCheck);
        }

        function onPlayerReady(event) {
            myStepCheck = window.requestAnimationFrame(stepCheck);
            //USE COOKIE TO FIND WHERE WHERE USER LAST PAUSED
            nextPlayer.seekTo(getEpisodePausedTime(episodeId), true);
        }

        function onPlayerStateChange(event) {
            if(event.data == 0) {
                //video eneded
                videoEnded();
            }
        }
    }



    $('body').on('click', '.openNextPlayer', function() {
        nextPlayerOpened = true;
        episodeId = $(this).attr('data-youtube');
        openNextPlayer(episodeId);
        stopScroll();
    });

    $('body').on('click', '.closeNextPlayer', function() {
        cancelAnimationFrame(myStepCheck);
        nextPlayerOpened = false;
        startScroll();
        $('.layout-nextPlayer').remove();
        // $('.episodeBtn').html('Resume episode '+thisEpisode.episode+'');
        $('.episodeBtn').html('Continue Watching ');
    });

    $('body').on('click', '.nextEpisodeBtn', function() {
        videoEnded();
    });

    function videoEnded() {
        //Run findNextEpisode() once only!
        nextEpisodeNo = parseInt($('.nextEpisodeBtn').attr('data-nextEpisode-no'));
        if(!isNaN(nextEpisodeNo)) {
            foundNextEpisode = findNextEpisode(nextEpisodeNo);
            foundNextEpisodeNo = foundNextEpisode.no;
            foundNextEpisodeId = foundNextEpisode.id;

            nextEpisodeId = allSeasons[thisSeason].find(function(x) {
                return x.episode === nextEpisodeNo;
            }).id;

            nextEpisodeUrl = allSeasons[thisSeason].find(function(x) {
                return x.episode === nextEpisodeNo;
            }).url;

            //play next episode
            nextPlayer.loadVideoById({'videoId':  nextEpisodeId, 'suggestedQuality': 'large'});

            updateEpisodePauseTimeCookies(findPreviousEpisode(nextEpisodeNo).id, 0);
        }

        if(foundNextEpisodeNo != -1) {
            // if next video avaliable to play
            //update close btn if currently playing season 2
            if(thisSeason == 'season2') {
                $('.closeNextPlayer').attr('href', nextEpisodeUrl);
                $('.closeNextPlayer').unbind(); //to behave like an a tag
            }

            if(thisSeason == 'season1') {
                $('.closeNextPlayer').attr('href', 'season-1.html');
                $('.closeNextPlayer').unbind(); //to behave like an a tag
            }

            //update next button
            $('.nextEpisodeBtn').attr('data-nextEpisode-no', foundNextEpisodeNo);

            setTimeout(function() {
                $('.nextEpisodeBtn .nextEpisodeNo').html(foundNextEpisodeNo);
                if(foundNextEpisodeNo == 1) {
                    $('.nextEpisodeBtn .thisSeason').html(1);
                } else {
                    $('.nextEpisodeBtn .thisSeason').html(thisSeason.split('season')[1]);
                }

            }, 200);
        } else {
            $('.nextEpisodeBtn').remove();
        }


    }

    //END SEASON 2 PLAYER JS
}




var owl3ColHoverMobCaro = $('.owl3ColHoverMobCaro');
owl3ColHoverMobCaro.owlCarousel({
    stagePadding: 0,
    margin: 25,
    items: 1,
    responsive: {
        1025 : {
            stagePadding: 0,
            margin: 25,
            items: 3
        }
    }
});

var owlTeamCaro = $('.owlTeamCaro');
owlTeamCaro.owlCarousel({
    stagePadding: 0,
    margin: 25,
    items: 1,
    autoHeight: true,
    touchDrag: false,
    mouseDrag: false,
});

$('.teamNav h3:not(.cen)').click(function(){

    $('.teamNav h3').removeClass('active');
    $(this).addClass('active');
    if($(this).index() == 0) {
        owlTeamCaro.trigger('to.owl.carousel', 0)
    } else {
        owlTeamCaro.trigger('to.owl.carousel', 1)
    }
});







var owlfullOwlCaro = $('.owlfullOwlCaro');
owlfullOwlCaro.owlCarousel({
    stagePadding: 0,
    margin: 0,
    items: 1,
    loop: true,
    nav: true,
    responsive: {
        468 : {
            stagePadding: 60,
            margin: 20,
            items: 1,
        },
        1024 : {
            stagePadding: 130,
            margin: 20,
            items: 1,
        }
    }
});











var owlfullOwlCaroWithArr = $('.owlfullOwlCaroWithArr');
owlfullOwlCaroWithArr.owlCarousel({
    margin: 20,
    stagePadding: 20,
    items: 1,
    nav: 1,
    loop: 1,
    autoplay: true,
    responsive: {
        1025 : {
            margin: 50,
            stagePadding: 50,
            items: 1,
        }
    }
});




//Youtube
$(document).ready(function () {
    if ($('.layout-masonryCollage').length) {
        var masonryCollage = $('.layout-masonryCollage .grid');
        masonryCollage.isotope({
          masonry: {
            itemSelector: '.grid-item',
            percentPosition: true,
            columnWidth: '.grid-sizer',
            gutter: 20
          }
        })
        masonryCollage.imagesLoaded().progress( function( instance, image ) {
          var result = image.isLoaded;

          if(result){
            $(image.img).parent('.grid-item').addClass('activate');
          }

          masonryCollage.isotope('layout');
        });
        var resizeTimer;
        $(window).on('resize', function(e) {
          clearTimeout(resizeTimer);
          resizeTimer = setTimeout(function() {
            masonryCollage.isotope('layout');
          }, 250);
        });
    }
});




/////////////// COUNT UP //////////////////////////

if($('.layout-Facts').length) {
    var factsOptions = {
    useEasing: false,
      useGrouping: true,
      separator: ',',
      decimal: '.',
    };
    var waypoint = new Waypoint({
        element: $('.layout-Facts'),
        handler: function(direction) {
            if(direction == 'down'){
                var factsCount = new CountUp('countOne', 0, 1.3, 1, 1, factsOptions);
                factsCount.start();
                // var factsCount2 = new CountUp('countTwo', 0, 1, 0, 1, factsOptions);
                // factsCount2.start();
                var factsCount3 = new CountUp('countThree', 0, 866667, 0, 1, factsOptions);
                factsCount3.start();
                var factsCount4 = new CountUp('countFour', 0, 50, 0, 1, factsOptions);
                factsCount4.start();
                var factsCount5 = new CountUp('countFive', 0, 2.5, 1, 1, factsOptions);
                factsCount5.start();
            }
        },
        offset: '40%'
    })
}




// MUSICAL JS ====================================================================================================================================================================================================================================================
// ====================================================================================================================================================================================================================================================
// ====================================================================================================================================================================================================================================================

if($('#sparksMusical').length) {
    var owlBelieve = $('.owlBelieve');
    owlBelieve.owlCarousel({
        items: 1,
        slideBy: 1,
        stagePadding: 50,
        margin: 20,
        responsive:{
            768:{
                items: 3,
                slideBy: 3
            },
            1024:{
                items: 4,
                slideBy: 4
            }
        }
    });

    var owlTheSeries = $('.owlTheSeries');
    owlTheSeries.owlCarousel({
        items: 1,
        slideBy: 1,
        stagePadding: 50,
        margin: 20,
        responsive:{
            768:{
                items: 3,
                slideBy: 3
            },
            1024:{
                items: 4,
                slideBy: 4
            }
        }
    });

    var controller = new ScrollMagic.Controller();
    $('.imgBlur').each(function(){
        var current = this;
        var tween = TweenMax.to($(this), 0.3, {y: '-30%', ease: Linear.easeNone});
        var scene = new ScrollMagic.Scene({triggerElement: current, duration: '100%'})
            .setTween(tween)
            .tweenChanges(true)
            .triggerHook('onEnter')
            .addTo(controller);
    });

    $('.storyWrap > div').each(function(){
        var current = this;
        var tween = TweenMax.to($(this), 0.3, {y: '-15%', ease: Linear.easeNone});
        var scene = new ScrollMagic.Scene({triggerElement: current, duration: '100%'})
            .setTween(tween)
            .tweenChanges(true)
            .triggerHook('onEnter')
            .addTo(controller);
    });


    $('.upSlow').each(function(){
        var current = this;
        var tween = TweenMax.to($(this), 0.1, {y: '-30%', ease: Linear.easeNone});
        var scene = new ScrollMagic.Scene({triggerElement: current, duration: '100%'})
            .setTween(tween)
            .tweenChanges(true)
            .triggerHook('onEnter')
            .addTo(controller);
    });

    $('.upNormal').each(function(){
        var current = this;
        var tween = TweenMax.to($(this), 0.1, {y: '-50%', ease: Linear.easeNone});
        var scene = new ScrollMagic.Scene({triggerElement: current, duration: '100%'})
            .setTween(tween)
            .tweenChanges(true)
            .triggerHook('onEnter')
            .addTo(controller);
    });

    $('.upFast').each(function(){
        var current = this;
        var tween = TweenMax.to($(this), 0.1, {y: '-70%', ease: Linear.easeNone});
        var scene = new ScrollMagic.Scene({triggerElement: current, duration: '100%'})
            .setTween(tween)
            .tweenChanges(true)
            .triggerHook('onEnter')
            .addTo(controller);
    });

    TweenMax.to(".seamlessBtm .sparkleLess, .seamlessTop .sparkleLess", 1.2, {opacity: 0, scale: 1.2, ease:RoughEase.ease.config({strength: 0.3, points: 8, randomize: true}), repeat: -1, yoyo: true });
    TweenMax.to(".seamlessBtm .sparkleNormal, .seamlessTop .sparkleNormal", 0.6, {opacity: 0, scale: 1.6, ease:RoughEase.ease.config({strength: 0.3, points: 8, randomize: true}), repeat: -1, yoyo: true });
    TweenMax.to(".seamlessBtm .sparkleMore, .seamlessTop .sparkleMore", 0.8, {opacity: 0, scale: 2.4, ease:RoughEase.ease.config({strength: 0.3, points: 8, randomize: true}), repeat: -1, yoyo: true });
    TweenMax.to(".seamlessBtm .sparkleFast, .seamlessTop .sparkleFast", 0.3, {opacity: 0, scale: 1.6, ease:RoughEase.ease.config({strength: 0.3, points: 8, randomize: true}), repeat: -1, yoyo: true });

    $('.titleWrap h2').waypoint({
        handler: function(dir) {
            if(dir == 'down'){
                $(this.element).addClass('activate');

                var tl = new TimelineLite,
                    mySplitText = new SplitText($(this.element), {type:"words,chars"}),
                    chars = mySplitText.chars;
                tl.staggerFrom(chars, 1, {opacity: 0, y:'50%', textShadow: '10px 10px 10px #FFF', ease:Back.easeOut}, 0.01, "+=0");

                TweenMax.set($(this.element).siblings('div').children('.line'), {width: '0%'});
                TweenMax.to($(this.element).siblings('div').children('.line'), 1, {width: '100%', delay: 0.3, ease: Power4.easeInOut});
            } else {
                $(this.element).removeClass('activate');
            }
        },
        offset: '100%'
    });

    $('.fadeUp').waypoint({
        handler: function(dir) {
            if(dir == 'down'){
                $(this.element).addClass('activate');
            } else {
                $(this.element).removeClass('activate');
            }
        },
        offset: '100%'
    });

    if ($('#musicalCast').length > 0) {
      $('[data-fancybox="castImages"]').fancybox({
        openEffect : 'elastic',
        closeEffect : 'elastic',
        arrows: true,
        toolbar: true,
        btnTpl: {
            // Arrows
            arrowLeft:
            '<button data-fancybox-prev="" class="fancybox-button fancybox-button--arrow_left" title="Previous" disabled="">' +
            "</button>",

            arrowRight:
            '<button data-fancybox-next="" class="fancybox-button fancybox-button--arrow_right" title="Next">' +
            "</button>"
        }
      });
    }
}

if($('#sparksGallery').length) {
    // masonry
    if ($('#container').length > 0) {
        var $grid = $('.grid');

        $(document).ready(function() {
            $grid.isotope({
              itemSelector: '.grid-item',
              percentPosition: true,
              masonry: {
                columnWidth: '.grid-sizer',
                gutter: 20
                // isFitWidth: true
              }
            })

            $grid.imagesLoaded().progress( function( instance, image ) {
              var result = image.isLoaded;

              if(result){
                $(image.img).parent('a').addClass('activate');
              }

              $grid.isotope('layout');
            });
        });
    }

    $(".fancybox").fancybox({
        openEffect : 'elastic',
        closeEffect : 'elastic',
        arrows: true,
        toolbar: true
    });
}

// =============================================================
// END MUSICAL JS =============================================================



if($('.pledgeCount').length) {

  if(!Cookies.get('pledge')) {
      Cookies.set('pledge', 0, { expires: 365 });
  }

  function hidePledge() {
      $('.layout-pledge').addClass('pledged');
      $('.layout-pledge .pledgeBtn').remove();
  }

  function showPledgeBtn() {
      $('.layout-pledge').removeClass('pledged');
  }

  //Firebase ////////////////////////////////////////////////
  var count = 0;
  var ref = firebase.database().ref('counts');
  ref.on("value", function(snapshot) {
      count = snapshot.val();

      function numberWithCommas(x) {
          return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }

      val = parseInt(count);
      //Use the code in the answer above to replace the commas.
      val = numberWithCommas(val);
      $('.pledgeCount').html(val);

      if(Cookies.get('pledge') > 0) {
          hidePledge();
      } else {
          showPledgeBtn();
      }

      $('.layout-pledge').addClass('active');
  }, function (error) {
     // console.log("Error: " + error.code);
  });

  $('.pledgeBtn').click(function(){
    count++;
    Cookies.set('pledge', 1, { expires: 365 });
    firebase.database().ref('counts').set(count);
    hidePledge()
  });
}



// RUN LAST
allFully();
Waypoint.refreshAll();

if($('.layout-season2Nav').length) {
    // var controller = new ScrollMagic.Controller();
    // var scene = new ScrollMagic.Scene({triggerElement: ".layout-season2Nav"})
    //             .triggerHook(0)
    //             .offset(-60)
    //             .setClassToggle(".layout-season2Nav","active")
    //             .setPin(".layout-season2Nav")
    //             .addTo(controller);

    $('.layout-season2TopFold').waypoint({
        handler: function(dir) {
            if(dir == 'down'){
                $('.layout-season2Nav').addClass('pinned');
            } else {
                $('.layout-season2Nav').removeClass('pinned');
            }
        },
        offset: function() {
            return -this.element.clientHeight + $('.layout-season2Nav').outerHeight() + 60
        }
    });

    function updateNav(num) {
        w = $(".layout-season2Nav a").eq(num).width();
        xPos = 0;
        for (i = 0; i < num; i++) {
            xPos += $(".layout-season2Nav a").eq(i).outerWidth() + parseInt($(".layout-season2Nav a:last-of-type").css('margin-left'));
        }
        TweenMax.to(('.layout-season2Nav .line'), 0.5, {width: w, x: xPos-1, ease: Power4.easeOut});


    }
    updateNav(0);

    $('.layout-season2Nav a').click(function(){
        $('.layout-season2Nav a').removeClass('active');
        $(this).addClass('active');

        index = $(this).index()-1;
        updateNav(index);

        if(index == 0) {
            TweenMax.to($('.layout-season2Nav'), 0.3, {scrollTo:{x:0, autoKill:false}, ease:Power2.easeInOut});
        } else if (index == 3) {
            TweenMax.to($('.layout-season2Nav'), 0.3, {scrollTo:{x:$('.layout-season2Nav').outerWidth(), autoKill:false}, ease:Power2.easeInOut});
        } else {
            TweenMax.to($('.layout-season2Nav'), 0.3, {scrollTo:{x:$(this), offsetX:$('.layout-season2Nav').outerHeight(), autoKill:false}, ease:Power2.easeInOut});
        }
    });

    var owlSeason2Contents = $('.owlSeason2Contents');
    owlSeason2Contents.owlCarousel({
        stagePadding: 0,
        margin: 0,
        items: 1,
        touchDrag: false,
        mouseDrag: false,
        autoHeight:true
    });

    var scrollToTimer;

    $('.layout-season2Nav .trueStoryBtn').click(function(){
        owlSeason2Contents.trigger('to.owl.carousel', 0)
        clearTimeout(scrollToTimer);
            resizeTimer = setTimeout(function() {
                TweenMax.to(window, 1.3, {scrollTo:{y:0, autoKill:false}, ease:Power2.easeInOut, onComplete: function(){
                    Waypoint.refreshAll();
                }});
            }, 50);
    });

    $('.layout-season2Nav .takeActionBtn').click(function(){
        owlSeason2Contents.trigger('to.owl.carousel', 0)
        clearTimeout(scrollToTimer);
            offsetVal = $('header').outerHeight() + $('.layout-season2Nav').outerHeight();
            resizeTimer = setTimeout(function() {
                TweenMax.to(window, 1.3, {scrollTo:{y:".takeAction", offsetY:offsetVal, autoKill:false}, ease:Power2.easeInOut, onComplete: function(){
                    Waypoint.refreshAll();
                }});
            }, 50);
    });

    $('.layout-season2Nav .extrasBtn').click(function(){
        owlSeason2Contents.trigger('to.owl.carousel', 1)
        clearTimeout(scrollToTimer);
            offsetVal = $('header').outerHeight() + $('.layout-season2Nav').outerHeight();
            resizeTimer = setTimeout(function() {
                TweenMax.to(window, 1.3, {scrollTo:{y:$('.owlSeason2Contents'), offsetY:offsetVal, autoKill:false}, ease:Power2.easeInOut, onComplete: function(){
                    Waypoint.refreshAll();
                }});
            }, 50);
    });

    $('.layout-season2Nav .moreEpisodesBtn').click(function(){
        owlSeason2Contents.trigger('to.owl.carousel', 2)
        clearTimeout(scrollToTimer);
            offsetVal = $('header').outerHeight() + $('.layout-season2Nav').outerHeight();
            resizeTimer = setTimeout(function() {
                TweenMax.to(window, 1.3, {scrollTo:{y:$('.owlSeason2Contents'), offsetY:offsetVal, autoKill:false}, ease:Power2.easeInOut, onComplete: function(){
                    Waypoint.refreshAll();
                }});
            }, 50);
    });

}



function hideSideBarSparksSeason2() {
    $('.sideBarSparksSeason2').remove();
    if(!Cookies.getJSON('sideBarClose')) {
        Cookies.set('sideBarClose', 1, { expires: 1 });
    }
}

if(Cookies.getJSON('sideBarClose') > 0) {
    hideSideBarSparksSeason2();
};


$('.sideBarSparksSeason2').click(function(){
    hideSideBarSparksSeason2();
});


