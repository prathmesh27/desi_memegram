$( document ).ready(function() {
	$("#covered-bonds-disclaimer .btn-primary").click(function(){
		$("#covered-bonds-disclaimer").hide();
		$("#covered-bonds-detail").show();	
	});

    //$("#newsCountryFilter option:first-child").text("All Markets");
    $("#newsCountryFilter").html("");
    $("#newsCountryFilter").html('<option value="ALL">All Markets</option><option value="sg">Singapore</option><option value="cn">Mainland China</option><option value="hk">Hong Kong</option><option value="in">India</option><option value="id">Indonesia</option><option value="regional">Regional</option><option value="tw">Taiwan</option>');  
  	
   /* menu hack selected for foundation */
  	var currentURL = window.location.href;
  	switch (currentURL){
      case "https://dbswebprv-grp-p01.corp.dbs.com/gsmc-grp/foundation/default.page":
      case "http://dbswebprv-grp-p01.corp.dbs.com/gsmc-grp/foundation/default.page":
      case "https://www.dbs.com/gsmc-grp/foundation/default.page":
      case "http://www.dbs.com/gsmc-grp/foundation/default.page":
      case "https://www.dbs.com/foundation/default.page":
      case "http://www.dbs.com/foundation/default.page":          
        	$("#flpHeader .navbar-links-left li").removeClass("active");
        	$("#flpHeader .navbar-links-left li:nth-child(6)").addClass("active");
        	break;
    }
  
  	/* Menu - Research Tab */
  	$(".navbar-links-left ul li:last-child a").attr("target","_blank");
  
    /* For Homepage */
    $(".our-awards").parent().removeClass('mTop-88');
    $(".gsmc-home-container .story-card-container").removeClass('mBot-72');
  
    var width = $(window).width(); 
    if ( width <= 768  ) {
      $(".gsmc-home-container").parent().css("margin-top",0);
      $(".gsmc-home-container .mTop-64").css("margin-top","32px");
    }
  	
  	s.t();

  $(".sip-btn1").click(function(){
    dataLayer.push({
      'event': 'interactionEvent',
      'eventCategory': 'Social impact prize – page',
      'eventAction': 'Hyperlink click',
      'eventLabel': 'https://www.dbs.com/iwov-resources/images/foundation/our-support/pdf/DBSF-Social-Impact-Prize-infographic-small.pdf',
    });  
  });

  $(".sip-btn2").click(function(){
    dataLayer.push({
      'event': 'interactionEvent',
      'eventCategory': 'Social impact prize – page',
      'eventAction': 'Hyperlink click',
      'eventLabel': 'https://www.smu.edu.sg/lky',
    });  
  });
  
  $(".sip-btn3").click(function(){
    dataLayer.push({
      'event': 'interactionEvent',
      'eventCategory': 'Social impact prize – page',
      'eventAction': 'Hyperlink click',
      'eventLabel': 'https://smucompetitions.fluidreview.com/',
    });  
  });   
  
  /* Hide story read time */
  window.setInterval(function(){   
    $(".storyTile .gray1-text").each(function(count,ele){
      var msg = $(ele).text();
      $(ele).text( msg.substring(0,11));	
    })
  }, 500);  
  
  $('#markets').on('change', function() {
        $(".btn-emap-apply").attr("href", this.value );
    });
  
  
  function customtagging() {
  	var query = window.location.search;
  	if (query) {
  		var currhref = $("a#applynow").attr("href");
  		query = query.replace(/utm_/g, "dbsf_");
  		$("a#applynow").attr("href", currhref + query);
  	}
  }
  customtagging();
  
  if ( window.location.href.indexOf("covid-19/portraits-of-purpose") > -1) {	
  } else {
      $("#mobileSlideMenu #megaMenuParent").append('<li class="panel txt-small"><a target="_self" href="/covid-19/portraits-of-purpose/index.html">Covid-19 and beyond</a></li>');
  }  
  
});	
