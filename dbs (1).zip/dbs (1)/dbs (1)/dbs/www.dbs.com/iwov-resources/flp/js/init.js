var sortElementsLists = function (obj) {

    $(obj).find('li').sort(function (a, b) {
        if (a.textContent < b.textContent) {
            return -1;
        } else {
            return 1;
        }
    }).appendTo($(obj));
}
var isEmpty = function (obj) {
    if (obj == null) return true;
    if (obj.length > 0) return false;
    if (obj.length === 0) return true;
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }
    return true;
};
function combine(a, b, c) {
    return processArrays([].slice.call(arguments), "", []);

    function processArrays(arrays, str, res) {
        for (var i = 0; i < arrays[0].length; i++) {
            if (arrays.length > 1) {
                processArrays(arrays.slice(1), str + arrays[0][i], res);
            } else {
                res.push(str + arrays[0][i]);
            }
        }
        return res;
    }
}


var filters = [];
var filtersBase = [];
var filtersBase2 = [];
var filtersRun = [];
var incIndustry = [];
var incIndustryClass = [];
var incCountry = [];
var incCountryClass = [];
var incSocialCause = [];
var incSocialCauseClass = [];
var articleLists;

var storyFiltersBase = [];
var storyFiltersBase2 = [];
var storyFiltersRun = [];
var incStoryTopics = [];
var incStoryTopicsClass = [];
var incStoryCategory = [];
var incStoryCategoryClass = [];
var storyLists;

var tileOptions;



var multiSelectLists = {
    classNames: {
        country: $('<div></div>'),
        industry: $('<div></div>'),
        socialcause: $('<div></div>'),
        storyTopic: $('<div></div>'),
        storyCategory: $('<div></div>'),
    },
    country: [],
    industry: [],
    socialcause: [],
    storyTopic: [],
    storyCategory: [],
};
var expandedView = false;
var changed = false;
var currentFilterName = "";

(function ($) {
    $(document).ready(function () {
        initSEDReady();
        initStoryReady();
        //initEvents();
    });
})(jQuery)

function initSEDReady() {
    if ($('#SED-article-list').length >= 1) {
        $('#SED-article-list').closest('.container').attr('data-listParam', 'artileListParams');
        params.artileListParams = {
            filterListName: "articleLists",
            itemContainer: $("#SED-article-list"),
            listItemName: "Article List",
            searchKeys: ['title', 'country', 'countryLabel', 'industry', 'industryLabel', 'socialCause', 'socialCauseLabel'],
            paginationCurrentPage: 1,
            pagesStartFrom: 1,
            totalPages: 0,
            totalListCount: 0,
            currentCount: 0,
            startingRecord: 1
        };
        initSED();
        initEvents();
    }
}
function initStoryReady() {
    if ($('#storyCards').length >= 1) {
        $('#storyCards').closest('.container').attr('data-listParam', 'storyListParams');
        params.storyListParams = {
            filterListName: "storyLists",
            itemContainer: $("#storyCards"),
            listItemName: "Story List",
            searchKeys: ['storytitle', 'subtitle', 'storytopic', 'storycategory'],
            paginationCurrentPage: 1,
            pagesStartFrom: 1,
            totalPages: 0,
            totalListCount: 0,
            currentCount: 0,
            startingRecord: 1
        };
        initStories();
        initEvents();
    }
}
function initEvents() {
    //$.searchAnimate();
    $.searchInit();
    $.searchInit('.search-boxslide');
    $(".search-boxslide .btn-search").off('click');
    setTimeout(function () {
        $.searchAnimate();
    }, 200);

    //handling the dropdown click event inside the filter popup
    $('.filter-menu').on('click', function (e) {
        if ($(e.target).parents(".multiselect").length === 0) {
            if ($('.input-wrapper.show').closest('.multiselect').length) {
                resetSelect($('.input-wrapper.show').closest('.multiselect'), true);
            }
            if ($('.pillsExpanded').closest('.multiselect').length) {
                resetSelect($('.pillsExpanded').closest('.multiselect'), true);
            }
        }
    });

    $(document).on('click touchstart', function (e) {
        e.stopPropagation();
        selectedList = {};

        $(".multiselect:visible").each(function (index) {
            if ($(e.target).parents(".multiselect").length === 0) {
                resetSelect(this, true)
            }
        });
        if ($(e.target).parents(".search-boxslide").length === 0) {
            if ($('.search-boxslide').find('.filterSearch').val() !== "") {
                setTimeout(function () {
                    $('.search-boxslide').not('.slide-animate').addClass('slide-animate');
                },0);
            }
            else{
                setTimeout(function () {
                    $('.search-boxslide.slide-animate').removeClass('slide-animate');
                },0);
            }
        }

    });

    // Handle arrow
    $(".arrow-icon, .chips-container").on("click", function (e) {
        if ($(this).closest('.container').find(".multiselect").not($(this).closest(".multiselect")).length) {
            resetSelect($(this).closest('.container').find(".multiselect").not($(this).closest(".multiselect")), false);
        }
        //$('.multiselect').not($(this).closest(".multiselect")).find(".options:visible").toggle();
        var multiselect = $(this).closest(".multiselect");

        $(multiselect).css('z-index', '999');

        if ($(e.target).hasClass("basic-chip")) {
            e.stopPropagation();
            return;
        } else if ($(e.target).hasClass("close-icon")) {
            e.stopPropagation();
            removeChip($(e.target), multiselect);
            return;
        }
        multiselect.find(".input-wrapper").toggleClass("show");


        setDropdownWidth();
        multiselect.find(".options:first").toggle();
        multiselect.find(".input-wrapper:first").toggleClass("remove-border");
        if (multiselect.find(".search:visible").val() && multiselect.find(".search:visible").val() !== "") {
            multiselect.find(".input-wrapper").find('.ico-cancel1').show();
        }
    });

    var width = $(window).width();
    $(window).on("resize", function () {
        _.debounce(
            function () {
                setDropdownWidth();
            },
            100,
            false
        )();
    });

    $(window).bind('orientationchange', function (e) {
        setTimeout(function () {
            $('.filter-dropdown').removeClass('show');
            $('.filter-menu').removeClass('show');
            resetSelect($('.multiselect'), false);
        }, 250);

    });

    $('.multiselect .ico-cancel1').on('click', function () {
        $(this).closest('.multiselect').find('input').val('');
        filterListItems($(this).closest('.multiselect'));
    });

    $('.mobFilter').on('visibility', function (e) {
        var thisParent = $(this).closest('.container');
        $(".multiselect").each(function (index) {
            var listItemName = $(this).data('name');
            if (e.visible) {
                $(this).appendTo(".mobFilter .mobileFilterItem ." + listItemName);
            }
            else {
                $(this).appendTo(".dtFilter ." + listItemName + ":visible");
            }
        });
        if (thisParent.find('.filterSearch:hidden').val() !== "") {
            thisParent.find('.filterSearch:visible').val($('.filterSearch:hidden').val());
            thisParent.find('.filterSearch:hidden').val('');
            thisParent.find('.filterSearch:visible').closest('.search-box').find('.icon.ico-arrowright3').removeClass('ico-search').addClass('ico-arrowright3');
            thisParent.find('.filterSearch:visible').closest('.search-box').find('.btn-close').show();
            thisParent.find('.filterSearch:visible').closest('.search-box').addClass('slide-animate');
            thisParent.find('.filterSearch:visible').closest('.search-box').find('.icon.ico-search').addClass('ico-arrowright3').removeClass('ico-search');
        }
        else if (thisParent.find('.filterSearch:visible').val() == "") {
            // $('.SEDSearch:visible').val('');
            thisParent.find('.filterSearch:visible').closest('.search-box').find('.btn-close').hide();
            thisParent.find('.filterSearch:visible').closest('.search-box').removeClass('slide-animate');
            thisParent.find('.filterSearch:visible').closest('.search-box').find('.icon.ico-arrowright3').addClass('ico-search').removeClass('ico-arrowright3');
        }
    });


    $(".btnClearFilter").on("click", function (e) {
        e.preventDefault();
        var param = params[$(this).closest('.container').attr('data-listparam')];
        multiselectInit(param.itemContainer);
        resetSelect(param.itemContainer.closest('.container').find(".multiselect"), true);
        eval(param.filterListName).filter();
        //$('.panel-body ul li').show();
        //$('.panel-body ul li input[type="checkbox"]').prop('checked', false);
        param.itemContainer.closest('.container').find(".multiselect:visible")
            .find(".options li")
            .removeClass("filterHide");
        incCountry = [];
        incIndustry = [];
        incSocialCause = [];
        filtersBase = [];
        filtersBase2 = [];

        prepareFilterPagination(param, true);
        $("html, body").animate(
            {
                scrollTop: param.itemContainer.closest('.container').offset().top - $(".header-placeholder").outerHeight()
            },
            1000
        );
    });

    $('.dtFilter .btn-search,.dtFilter .btn-close,.mobFilter .btn-search,.mobFilter .btn-close').on('click', function () {
        /*if ($(this).find('.ico-search').length) {
            return false;
        }*/
        if ($(this).find('.ico-arrowright3').length) {
            var searchString = $(this).closest('.search-box').find('.filterSearch').val();
        }
        else if ($(this).hasClass('btn-close')) {
            $(this).closest('.search-box').find('.filterSearch').val('');
            var searchString = "";
        }
        else if (!$(this).find('.ico-arrowright3').length && $(this).closest('.search-boxslide').length && $(this).closest('.search-boxslide').hasClass('slide-animate')) {
            return false;
        }

        var paramList = params[$(this).closest('.container').attr('data-listparam')];
        var searchKeys = paramList.searchKeys;
        eval(paramList.filterListName).search(searchString, searchKeys);



        prepareFilterPagination(paramList, true);
    });
    $('.filterSearch').on("keyup", function () {
        if (event.which == 13 && $(this).val() !== "") {
            $(".ico-arrowright3").trigger("click");
            event.preventDefault();
            return false;
        }
        if ($(this).val() == "") {
            var searchString = "";
            var paramList = params[$(this).closest('.container').attr('data-listparam')];
            var searchKeys = paramList.searchItems;
            eval(paramList.filterListName).search(searchString, searchKeys);
            prepareFilterPagination(paramList, true);
        }
    });





}

/* Trigger Filter */
filtersRun = function (country, industry, socialcause) {
    var fitlersCombine;
    articleLists.filter(function (item) {
        var returnArg = false;
        if (!isEmpty(country) && !isEmpty(industry) && !isEmpty(socialcause)) {
            fitlersCombine = combine(incCountryClass, incIndustryClass, incSocialCauseClass);
            if ($.inArray(item.values().country, country) !== -1 &&
                $.inArray(item.values().industry, industry) !== -1 &&
                $.inArray(item.values().socialCause, socialcause) !== -1) {
                returnArg = true;
            }
        } else if (!isEmpty(country) && !isEmpty(industry) && isEmpty(socialcause)) {
            fitlersCombine = combine(incCountryClass, incIndustryClass);
            if ($.inArray(item.values().country, country) !== -1 && $.inArray(item.values().industry, industry) !== -1) {
                returnArg = true;
            }

        } else if (!isEmpty(country) && isEmpty(industry) && !isEmpty(socialcause)) {
            fitlersCombine = combine(incCountryClass, incSocialCauseClass);
            if ($.inArray(item.values().country, country) !== -1 && $.inArray(item.values().socialCause, socialcause) !== -1) {
                returnArg = true;
            }
        } else if (isEmpty(country) && !isEmpty(industry) && !isEmpty(socialcause)) {
            fitlersCombine = combine(incIndustryClass, incSocialCauseClass);
            if ($.inArray(item.values().industry, industry) !== -1 && $.inArray(item.values().socialCause, socialcause) !== -1) {
                returnArg = true;
            }
        } else if (!isEmpty(country)) {
            fitlersCombine = country;
            var itemCountry = item.values().country.split(',');
            if (_.intersection(itemCountry, country).length > 0) {
                returnArg = true;
            }
            /* if ($.inArray(item.values().country, country) !== -1) {
                 returnArg = true;
             }*/
        } else if (!isEmpty(industry)) {
            fitlersCombine = industry;
            if ($.inArray(item.values().industry, industry) !== -1) {
                returnArg = true;
            }

        } else if (!isEmpty(socialcause)) {
            fitlersCombine = socialcause;
            if ($.inArray(item.values().socialCause, socialcause) !== -1) {
                returnArg = true;
            }
        } else {
            returnArg = true;
        }
        return returnArg;
    });

    //Side Filters

    //console.log(country);
    // console.log(industry);



    if (!isEmpty(fitlersCombine)) {
        if ((filtersBase2['type'] == 'industry' && isEmpty(industry))) {
            filtersBase2 = [];
        } else if ((filtersBase2['type'] == 'socialcause' && isEmpty(socialcause))) {
            filtersBase2 = [];
        } else if ((filtersBase2['type'] == 'country' && isEmpty(country))) {
            filtersBase2 = [];
        }

        $('.multiselect:visible').find('.options li').addClass('filterHide');
        $('.multiselect:visible').find('.options li' + fitlersCombine).removeClass('filterHide');

        $.each(articleLists.matchingItems, function (index, item) {
            $('.multiselect[data-name="country"]:visible li.' + item._values.country).removeClass('filterHide');
            $('.multiselect[data-name="industry"]:visible li.' + item._values.industry).removeClass('filterHide');
            $('.multiselect[data-name="socialcause"]:visible li.' + item.socialCause).removeClass('filterHide');
        });


        if (filtersBase['type'] == 'country') {
            $('.multiselect[data-name="country"]:visible li').removeClass('filterHide');
            if (isEmpty(country)) {
                $('.multiselect:visible li').removeClass('filterHide');
            }
            else {
                $.each(country, function (index, item) {
                    $('.multiselect:visible li.' + item).removeClass('filterHide');
                });
            }
            if (!isEmpty(filtersBase2)) {
                if ((filtersBase2['type'] == 'industry' && !isEmpty(industry)) || (filtersBase2['type'] == 'socialcause' && !isEmpty(socialcause))) {
                    $('.multiselect[data-name="country"]:visible li').addClass('filterHide');
                    $('.multiselect[data-name="country"]:visible li.' + filtersBase2['value']).removeClass('filterHide');


                    if (filtersBase2['type'] == 'industry') {
                        $('.multiselect[data-name="socialcause"]:visible li').addClass('filterHide');
                        $.each(articleLists.matchingItems, function (index, articleObj) {
                            $('.multiselect[data-name="socialcause"] li[data-key="' + articleObj._values.socialCause + '"]').removeClass('filterHide');
                        });
                    }
                    if (filtersBase2['type'] == 'socialcause') {
                        $('.multiselect[data-name="industry"]:visible li').addClass('filterHide');
                        $.each(articleLists.matchingItems, function (index, articleObj) {
                            $('.multiselect[data-name="industry"] li[data-key="' + articleObj._values.industry + '"]').removeClass('filterHide');
                        });
                    }
                }
            }
        }

        if (filtersBase['type'] == 'industry') {
            $('.multiselect[data-name="industry"]:visible li').removeClass('filterHide');
            if (isEmpty(industry)) {
                $('.multiselect:visible li').removeClass('filterHide');
            }
            else {
                $.each(industry, function (index, item) {
                    $('.multiselect:visible li.' + item).removeClass('filterHide');
                });
            }
            if (!isEmpty(filtersBase2)) {
                if ((filtersBase2['type'] == 'country' && !isEmpty(country)) || (filtersBase2['type'] == 'socialcause' && !isEmpty(socialcause))) {
                    $('.multiselect[data-name="industry"]:visible li').addClass('filterHide');
                    $('.multiselect[data-name="industry"]:visible li.' + filtersBase2['value']).removeClass('filterHide');

                    if (filtersBase2['type'] == 'country') {
                        $('.multiselect[data-name="socialcause"]:visible li').addClass('filterHide');
                        $.each(articleLists.matchingItems, function (index, articleObj) {
                            $('.multiselect[data-name="socialcause"] li[data-key="' + articleObj._values.socialCause + '"]').removeClass('filterHide');
                        });
                    }
                    if (filtersBase2['type'] == 'socialcause') {
                        $('.multiselect[data-name="country"]:visible li').addClass('filterHide');
                        $.each(articleLists.matchingItems, function (index, articleObj) {
                            $('.multiselect[data-name="country"] li[data-key="' + articleObj._values.country + '"]').removeClass('filterHide');
                        });
                    }
                }
            }
        }
        if (filtersBase['type'] == 'socialcause') {
            $('.multiselect[data-name="socialcause"]:visible li').removeClass('filterHide');
            if (isEmpty(socialcause)) {
                $('.multiselect:visible li').removeClass('filterHide');
            }
            else {
                $.each(socialcause, function (index, item) {
                    $('.multiselect:visible li.' + item).removeClass('filterHide');
                });
            }
            if (!isEmpty(filtersBase2)) {
                if ((filtersBase2['type'] == 'country' && !isEmpty(country)) || (filtersBase2['type'] == 'industry' && !isEmpty(industry))) {
                    $('.multiselect[data-name="socialcause"]:visible li').addClass('filterHide');
                    $('.multiselect[data-name="socialcause"]:visible li.' + filtersBase2['value']).removeClass('filterHide');

                    if (filtersBase2['type'] == 'country') {
                        $('.multiselect[data-name="industry"]:visible li').addClass('filterHide');
                        $.each(articleLists.matchingItems, function (index, articleObj) {
                            $('.multiselect[data-name="industry"] li[data-key="' + articleObj._values.industry + '"]').removeClass('filterHide');
                        });
                    }
                    if (filtersBase2['type'] == 'industry') {
                        $('.multiselect[data-name="country"]:visible li').addClass('filterHide');
                        $.each(articleLists.matchingItems, function (index, articleObj) {
                            $('.multiselect[data-name="country"] li[data-key="' + articleObj._values.country + '"]').removeClass('filterHide');
                        });
                    }
                }
            }
        }

        //console.log(country);
        //console.log(industry);
        //console.log(socialcause);

        // console.log(filtersBase);
        //console.log(filtersBase2);
    } else {
        //$('.panel-body ul li').show();
        $('.multiselect:visible').find('.options li').removeClass('filterHide');
        filtersBase = [];
        //filtersBase2 = [];
    }
};






/* Trigger Filter */
storyFiltersRun = function (storyTopic, storyCategory) {

    var fitlersCombine;
    storyLists.filter(function (item) {
        var returnArg = false;
        var topicLists = item.values().storytopic.split(',');
        if (!isEmpty(storyTopic) && !isEmpty(storyCategory)) {
            fitlersCombine = combine(incStoryTopicsClass, incStoryCategoryClass);
            if ($.inArray(item.values().storycategory, storyCategory) !== -1 &&
                _.intersection(topicLists, storyTopic).length > 0) {
                returnArg = true;
            }
        } else if (!isEmpty(storyCategory)) {
            fitlersCombine = storyCategory;
            if ($.inArray(item.values().storycategory, storyCategory) !== -1) {
                returnArg = true;
            }
        } else if (!isEmpty(storyTopic)) {
            fitlersCombine = storyTopic;
            if (_.intersection(topicLists, storyTopic).length > 0) {
                returnArg = true;
            }
        } else {
            returnArg = true;
        }
        return returnArg;
    });

    if (!isEmpty(fitlersCombine)) {
        if ((storyFiltersBase2['type'] == 'storyTopic' && isEmpty(storyTopic))) {
            storyFiltersBase2 = [];
        } else if ((storyFiltersBase2['type'] == 'storyCategory' && isEmpty(storyCategory))) {
            storyFiltersBase2 = [];
        }
        //console.log('fitlersCombine');
        //console.log(fitlersCombine);

        $('.multiselect:visible').find('.options li').addClass('filterHide');

        if (storyFiltersBase['type'] == 'storyTopic') {
            $('.multiselect[data-name="storyTopic"]:visible li').removeClass('filterHide');
            if (isEmpty(storyTopic)) {
                $('.multiselect:visible li').removeClass('filterHide');
            }
            else {
                $.each(storyTopic, function (index, item) {
                    $('.multiselect:visible li.' + item).removeClass('filterHide');
                });
            }
            if (!isEmpty(storyFiltersBase2)) {
                $('.multiselect[data-name="storyTopic"]:visible li').addClass('filterHide');
                if (isEmpty(storyCategory)) {
                    $('.multiselect[data-name="storyTopic"]:visible li').removeClass('filterHide');
                }
                else {
                    $.each(storyCategory, function (index, item) {
                        $('.multiselect[data-name="storyTopic"]:visible li.' + item).removeClass('filterHide');
                    });
                }
            }
        }

        if (storyFiltersBase['type'] == 'storyCategory') {
            $('.multiselect[data-name="storyCategory"]:visible li').removeClass('filterHide');
            if (isEmpty(storyCategory)) {
                $('.multiselect:visible li').removeClass('filterHide');
            }
            else {
                $.each(storyCategory, function (index, item) {
                    $('.multiselect:visible li.' + item).removeClass('filterHide');
                });
            }
            if (!isEmpty(storyFiltersBase2)) {
                $('.multiselect[data-name="storyCategory"]:visible li').addClass('filterHide');
                if (isEmpty(storyTopic)) {
                    $('.multiselect[data-name="storyCategory"]:visible li').removeClass('filterHide');
                }
                else {
                    $.each(storyTopic, function (index, item) {
                        $('.multiselect[data-name="storyCategory"]:visible li.' + item).removeClass('filterHide');
                    });
                }
            }
        }

    } else {
        $('.multiselect:visible').find('.options li').removeClass('filterHide');
        filtersBase = [];
    }
};


function initSED() {

    $.ajax({
        url: "/iwov-resources/flp/se-directory/js/se-directory.js",
        dataType: "json",
        cache: false,
        success: function (rawglobalContent) {
            var labelIndustry;
            var labelSocialCause;
            var labelCountry;
            var ctr = 0;
            var processContent = [];

            var rawContent = rawglobalContent;



            if (!isEmpty(rawContent)) {

                //sorting the content
                rawContent.sort(function (a, b) {

                    var nameA = $.trim(a.title.toLowerCase()), nameB = $.trim(b.title.toLowerCase())
                    if (nameA < nameB) //sort string ascending
                        return -1
                    if (nameA > nameB)
                        return 1
                    return 0 //default return value (no sorting)
                });

                $.each(rawContent, function (idx, obj) {

                    if (!isEmpty(obj.country)) {
                        if (multiSelectLists.classNames.country.find('#' + obj.country).length > 0) {
                            multiSelectLists.classNames.country.find('#' + obj.country).addClass(obj.country + ' ' + obj.industry + ' ' + obj.socialCause);
                        }
                        else {
                            multiSelectLists.classNames.country.append(['<div id="' + obj.country + '" class="' + obj.country + ' ' + obj.industry + ' ' + obj.socialCause + '" ',
                                '></div>'].join(''));
                        }
                        var itemLists = multiSelectLists.country.map(function (a) {
                            return a.itemKey;
                        });
                        if ($.inArray(obj.country, itemLists) == -1) {
                            multiSelectLists.country.push({
                                itemLabel: obj.countryLabel,
                                itemKey: obj.country
                            })
                        }
                    }
                    if (!isEmpty(obj.industry)) {
                        if (multiSelectLists.classNames.industry.find('#' + obj.industry).length > 0) {
                            multiSelectLists.classNames.industry.find('#' + obj.industry).addClass(obj.country + ' ' + obj.industry + ' ' + obj.socialCause);
                        }
                        else {
                            multiSelectLists.classNames.industry.append(['<div id="' + obj.industry + '" class="' + obj.country + ' ' + obj.industry + ' ' + obj.socialCause + '" ',
                                '></div>'].join(''));
                        }
                        var itemLists = multiSelectLists.industry.map(function (a) {
                            return a.itemKey;
                        });
                        if ($.inArray(obj.industry, itemLists) == -1) {
                            multiSelectLists.industry.push({
                                itemLabel: obj.industryLabel,
                                itemKey: obj.industry
                            })
                        }
                    }
                    if (!isEmpty(obj.socialCause)) {
                        if (multiSelectLists.classNames.socialcause.find('#' + obj.socialCause).length > 0) {
                            multiSelectLists.classNames.socialcause.find('#' + obj.socialCause).addClass(obj.country + ' ' + obj.industry + ' ' + obj.socialCause);
                        }
                        else {
                            multiSelectLists.classNames.socialcause.append(['<div id="' + obj.socialCause + '" class="' + obj.country + ' ' + obj.industry + ' ' + obj.socialCause + '" ',
                                '></div>'].join(''));
                        }
                        var itemLists = multiSelectLists.socialcause.map(function (a) {
                            return a.itemKey;
                        });
                        if ($.inArray(obj.socialCause, itemLists) == -1) {
                            multiSelectLists.socialcause.push({
                                itemLabel: obj.socialCauseLabel,
                                itemKey: obj.socialCause
                            })
                        }

                    }

                    $("#SED-article-list .list").append(['<div class="col-md-6 col-sm-6 sed-item ' + obj.country + ' ' + obj.industry + ' ' + obj.socialCause + ' visible"',
                    ' data-country="' + obj.country + '" data-industry="' + obj.industry + '" data-socialCause="' + obj.socialCause + '">',
                        '<div class="media media-box-type1 mb-0">',
                    '<div class="media-left"><a href="' + obj.website + '" class="website">',
                    '<img class="media-object imgName" src="' + obj.imgName + '"',
                    'alt="' + obj.title + '"> </a> </div>',
                        '<div class="media-body">',
                        '<div class="mediablock-header mb-3">',
                    '<p class="orange2-text bold-text countryLabel mb-0">' + obj.countryLabel + '</p>',
                    '<p class="gray1-text"><span class="industryLabel">' + obj.industryLabel + '</span><span class="news-dot-right"> . </span><span class="socialCauseLabel">' + obj.socialCauseLabel + '</span></p></div>',
                    '<h3 class="mb-0"><a href="' + obj.website + '"><span class="title">' + obj.title.replace(/&nbsp;/g, " ") + '</span></a></h3>',
                    '<p><a href="' + obj.website + '"><span class="description">' + obj.description.replace(/&nbsp;/g, " ") + '</span></a></p>',
                        '</div></div></div>'].join(''));
                    //obj.imgName = '/iwov-resources/se-directory/se-img/' + obj.imgName;
                    processContent.push(obj);
                });
            }



            multiSelectLists.country.sort(function (a, b) {
                var nameA = a.itemLabel.toLowerCase(), nameB = b.itemLabel.toLowerCase()
                if (nameA < nameB) //sort string ascending
                    return -1
                if (nameA > nameB)
                    return 1
                return 0 //default return value (no sorting)
            });
            multiSelectLists.industry.sort(function (a, b) {
                var nameA = a.itemLabel.toLowerCase(), nameB = b.itemLabel.toLowerCase()
                if (nameA < nameB) //sort string ascending
                    return -1
                if (nameA > nameB)
                    return 1
                return 0 //default return value (no sorting)
            });
            multiSelectLists.socialcause.sort(function (a, b) {
                var nameA = a.itemLabel.toLowerCase(), nameB = b.itemLabel.toLowerCase()
                if (nameA < nameB) //sort string ascending
                    return -1
                if (nameA > nameB)
                    return 1
                return 0 //default return value (no sorting)
            });
            console.log(multiSelectLists);
            multiselectInit(params.artileListParams.itemContainer);

            var options = {
                valueNames: [
                    'title',
                    'country',
                    'countryLabel',
                    'industry',
                    'industryLabel',
                    'socialCause',
                    'socialCauseLabel',
                    'description',
                    { name: 'website', attr: 'href' },
                    { name: 'imgName', attr: 'src' },
                    { data: ['country'] },
                    { data: ['industry'] },
                    { data: ['socialCause'] }
                ],
                item: ['<div class="col-md-6 col-sm-6 sed-item visible"',
                    'data-country="country" data-industry="industry" data-socialCause="socialCause">',
                    '<div class="media media-box-type1 mb-0">',
                    '<div class="media-left"><a href="/personal/promotion/tc0319teppan" class="website">',
                    '<img class="media-object imgName" src="https://www.dbs.com.sg/iwov-resources/media/images/offers/cards/684x630teppan0319.jpg"',
                    'alt="Asha Education"> </a> </div>',
                    '<div class="media-body">',
                    '<div class="mediablock-header mb-3">',
                    '<p class="orange2-text bold-text countryLabel mb-0"></p>',
                    '<p class="gray1-text"><span class="industryLabel"></span><span class="news-dot-right"> . </span><span class="socialCauseLabel"></span></p></div>',
                    '<h3 class="mb-0"><a href="/personal/promotion/tc0319teppan"><span class="title"></span></a></h3>',
                    '<p><a href="/personal/promotion/tc0319teppan"><span class="description"></span></a></p>',
                    '</div></div></div>'].join(''),
                page: 10,
                pagination: [{
                    outerWindow: 2,
                    innerWindow: 5
                }]
            };

            articleLists = new List('SED-article-list', options);
            params.artileListParams.currentCount = articleLists.visibleItems.length;
            prepareFilterPagination(params.artileListParams, true);

            /*if (articleLists.matchingItems.length > 1) {
                $(".itemCount").html(articleLists.matchingItems.length + " items found.")
            } else {
                $(".itemCount").html(articleLists.matchingItems.length + " item found.")
            }*/
        }
    });
}

function initStories() {
    $.ajax({
        method: "GET", //for Akamai Caching for GET methods
        url: $("#ajaxStoriesURL").val(),
        cache: false,
        async: true,
        dataType: "xml",
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        crossDomain: true,
        success: function (rawglobalContent) {
            var ctr = 0;
            var processContent = [];

           var jsonContent =  JSON.parse($(rawglobalContent).find("storiesJSON").text());

            var rawContent = jsonContent.tileList;
            tileOptions = jsonContent.tileOptions;

            if (!isEmpty(rawContent)) {
                $.each(rawContent, function (idx, obj) {
                    var topicLists;
                    if (!isEmpty(obj.DBS_Topic)) {
                        topicLists = obj.DBS_Topic.split(',');
                        $.each(topicLists, function (index, topic) {
                            if (multiSelectLists.classNames.storyTopic.find('#' + topic).length > 0) {
                                multiSelectLists.classNames.storyTopic.find('#' + topic).addClass(obj.DBS_Categories + ' ' + topic);
                            }
                            else {
                                multiSelectLists.classNames.storyTopic.append(['<div id="' + topic + '" class="' + obj.DBS_Categories + ' ' + topic + '" ',
                                    '></div>'].join(''));
                                multiSelectLists.storyTopic.push({
                                    itemLabel: obj.DBS_Topic_Label.split(',')[index],
                                    itemKey: topic
                                })
                            }
                        });
                    }
                    if (!isEmpty(obj.DBS_Categories)) {
                        if (multiSelectLists.classNames.storyCategory.find('#' + obj.DBS_Categories).length > 0) {
                            multiSelectLists.classNames.storyCategory.find('#' + obj.DBS_Categories).addClass(obj.DBS_Categories + ' ' + (topicLists ? topicLists.join(' ') : ''));
                        }
                        else {
                            multiSelectLists.classNames.storyCategory.append(['<div id="' + obj.DBS_Categories + '" class="' + obj.DBS_Categories + ' ' + (topicLists ? topicLists.join(' ') : '') + '" ',
                                '></div>'].join(''));
                            multiSelectLists.storyCategory.push({
                                itemLabel: obj.DBS_Categories_Label,
                                itemKey: obj.DBS_Categories
                            })
                        }
                    }
                    $("#storyCards .list").append(tiltTemplate(obj, idx, topicLists).join(''));
                    processContent.push(obj);
                });
            }

            multiSelectLists.storyTopic.sort(function (a, b) {
                var nameA = a.itemLabel.toLowerCase(), nameB = b.itemLabel.toLowerCase()
                if (nameA < nameB) //sort string ascending
                    return -1
                if (nameA > nameB)
                    return 1
                return 0 //default return value (no sorting)
            });
            multiSelectLists.storyCategory.sort(function (a, b) {
                var nameA = a.itemLabel.toLowerCase(), nameB = b.itemLabel.toLowerCase()
                if (nameA < nameB) //sort string ascending
                    return -1
                if (nameA > nameB)
                    return 1
                return 0 //default return value (no sorting)
            });


            multiselectInit(params.storyListParams.itemContainer);


            var storyOptions = {
                valueNames: [
                    'storytitle',
                    'subtitle',
                    'storytopic',
                    'storycategory',
                    'storyTopicLabel',
                    'storyCategoryLabel',
                    'shortimgPath',
                    'shortimgAlt',
                    'longimgPath',
                    'longimgAlt',
                    'footerDate',
                    'footerMins',
                    'categorycolor',
                    { name: 'website', attr: 'href' },
                    { name: 'imgName', attr: 'src' },
                    { data: ['storytopic'] },
                    { data: ['storycategory'] }
                ],
                /*item: ['<div class="col-md-4 col-sm-6 col-xs-12 visible"',
                ' data-storytopic="storyTopic" data-storycategory="storyCategory">',
                '<div class="layout-box type7"><a target="_self" class="website" href="/personal/promotion/tc0319teppan">',
                '<div class="img-cover background-image-wrapper"><img class="img-fluid no-dynamic-js-handle imgName" alt="test"',
                ' src="https://www.dbs.com.sg/iwov-resources/media/images/offers/cards/684x630teppan0319.jpg">',
                '</div><div class="layout-plain"><h4 class="story-title"></h4>',
                '<div class="card-tiles-footer">',
                '<p class="gray1-text"><span class="footerDate"></span>',
                '<span class="news-dot-right"> .</span><span class="footerMins"></span> min read</p></div></div></a></div></div>'].join(''),*/
                page: 10,
                pagination: [{
                    outerWindow: 2,
                    innerWindow: 5
                }]
            };
            storyLists = new List('storyCards', storyOptions);
            params.storyListParams.currentCount = storyLists.visibleItems.length;
            prepareFilterPagination(params.storyListParams, true);


            storyLists.on('updated', function () {
                storyLists.visibleItems.map(function (item, index) {
                    var topicLists = item._values.storytopic.split(',');
                    var obj = {
                        DBS_CardTile_Title: item._values.storytitle,
                        DBS_Categories: item._values.storycategory,
                        DBS_Categories_Label: item._values.storyCategoryLabel,
                        DBS_Stories_LinkURL: item._values.website,
                        DBS_CardTile_LongTileImageAltText: item._values.longimgAlt,
                        DBS_CardTile_LongTileImagePath: item._values.longimgPath,
                        DBS_CardTile_ShortTileImagePath: item._values.shortimgPath,
                        DBS_CardTile_ShortTileImageAltText: item._values.shortimgAlt,
                        DBS_CardTile_ShortDescription: item._values.subtitle,
                        DBS_Publication_date: item._values.footerDate,
                        DBS_Read_Duration: item._values.footerMins,
                        DBS_Categories_Color: item._values.categorycolor
                    }
                    var newItem = tiltTemplate(obj, index, topicLists).join('');
                    //$("#storyCards .list").append(tiltTemplate(obj, index, categories).join(''));
                    $(item.elm).attr('class', $(newItem).attr('class')).html($(newItem).html());
                });
            });

        }
    });
}

function tiltTemplate(obj, index, topicLists) {
    var tile = [];
    var footerLabel = $('<div></div>').append($('<p class="topicText bold-text storyCategoryLabel">' + obj.DBS_Categories_Label + '</p>').css("color", obj.DBS_Categories_Color));
    if (tileOptions[index] && tileOptions[index].tileType == "LONG_TILE") {
        tile = ['<div class="col-md-8 col-sm-6 col-xs-12 mmBtm-16 visible ' + obj.DBS_Categories + ' ' + (topicLists ? topicLists.join(' ') : '') + '"',
        ' data-storytopic="' + topicLists + '" data-storycategory="' + obj.DBS_Categories + '">',
        '<div class="layout-box type8 same-side"><a target="' + (tileOptions[index] ? tileOptions[index].linkTarget : "_self") + '" class="website" href="' + obj.DBS_Stories_LinkURL + '">',
            '<div class="row only-image"><div class="type8-box1 col-sm-12 col-md-6 d-none d-md-block">',
        '<img class="img-fluid no-dynamic-js-handle onlywh-image imgName" alt="' + obj.DBS_CardTile_LongTileImageAltText + '"',
        ' src="' + obj.DBS_CardTile_LongTileImagePath + '">',
        '</div><div class="type8-box2 col-sm-12 col-md-6"><h4 class="story-title storytitle">' + obj.DBS_CardTile_Title + '</h4>',
        '<p class="categorycolor d-none">' + obj.DBS_Categories_Color + '</p>',
        '<p class="storyCategoryLabel d-none">' + obj.DBS_Categories_Label + '</p>',
        '<p class="longimgPath d-none">' + obj.DBS_CardTile_LongTileImagePath + '</p>',
        '<p class="longimgAlt d-none">' + obj.DBS_CardTile_LongTileImageAltText + '</p>',
        '<p class="shortimgPath d-none">' + obj.DBS_CardTile_ShortTileImagePath + '</p>',
        '<p class="shortimgAlt d-none">' + obj.BS_CardTile_ShortTileImageAltText + '</p>',
        '<p class="sub-title subtitle">' + obj.DBS_CardTile_ShortDescription + '</p>',
        '<div class="card-tiles-footer">' + $(footerLabel).html(),
        '<p class="gray1-text"><span class="footerDate">' + obj.DBS_Publication_date + '</span>',
        '<span class="news-dot-right"> . </span><span class="footerMins">' + obj.DBS_Read_Duration + '</span> min read</p></div></div></div></a></div></div>'
        ];
    }
    else if (tileOptions[index] && tileOptions[index].tileType == "SHORT_TILE_CUSTOM") {
        tile = ['<div class="col-md-4 col-sm-6 col-xs-12 storyTile visible ' + obj.DBS_Categories + ' ' + (topicLists ? topicLists.join(' ') : '') + '"',
        ' data-storytopic="' + topicLists + '" data-storycategory="' + obj.DBS_Categories + '">',
        '<div class="layout-box type7"><a target="' + (tileOptions[index] ? tileOptions[index].linkTarget : "_self") + '" class="website" href="' + obj.DBS_Stories_LinkURL + '">',
        '<div class="layout-plain"><h4 class="storytitle story-title pTop-16 mb-3">' + obj.DBS_CardTile_Title.replace(/&lt;/g, "<").replace(/&gt;/g, ">") + '</h4>',
        '<p class="categorycolor d-none">' + obj.DBS_Categories_Color + '</p>',
        '<p class="storyCategoryLabel d-none">' + obj.DBS_Categories_Label + '</p>',
        '<p class="longimgPath d-none">' + obj.DBS_CardTile_LongTileImagePath + '</p>',
        '<p class="longimgAlt d-none">' + obj.DBS_CardTile_LongTileImageAltText + '</p>',
        '<p class="shortimgPath d-none">' + obj.DBS_CardTile_ShortTileImagePath + '</p>',
        '<p class="shortimgAlt d-none">' + obj.DBS_CardTile_ShortTileImageAltText + '</p>',
        '<p class="sub-title subtitle">' + obj.DBS_CardTile_ShortDescription + '</p>',
        '<div class="card-tiles-footer">' + $(footerLabel).html(),
        '<p class="gray1-text"><span class="footerDate">' + obj.DBS_Publication_date + '</span>',
        '<span class="news-dot-right"> . </span><span class="footerMins">' + obj.DBS_Read_Duration + '</span> min read</p></div></div></a></div></div>'
        ];
    }
    else {
        tile = ['<div class="col-md-4 col-sm-6 col-xs-12 visible ' + obj.DBS_Categories + ' ' + (topicLists ? topicLists.join(' ') : '') + '"',
        ' data-storytopic="' + topicLists + '" data-storycategory="' + obj.DBS_Categories + '">',
        '<div class="layout-box type7"><a target="' + (tileOptions[index] ? tileOptions[index].linkTarget : "_self") + '" class="website" href="' + obj.DBS_Stories_LinkURL + '">',
        '<div class="img-cover background-image-wrapper"><img class="img-fluid no-dynamic-js-handle imgName" alt="' + obj.DBS_CardTile_ShortTileImageAltText + '"',
        ' src="' + obj.DBS_CardTile_ShortTileImagePath + '">',
        '</div><div class="layout-plain"><h4 class="storytitle story-title">' + obj.DBS_CardTile_Title.replace(/&lt;/g, "<").replace(/&gt;/g, ">") + '</h4>',
        '<p class="categorycolor d-none">' + obj.DBS_Categories_Color + '</p>',
        '<p class="storyCategoryLabel d-none">' + obj.DBS_Categories_Label + '</p>',
        '<p class="longimgPath d-none">' + obj.DBS_CardTile_LongTileImagePath + '</p>',
        '<p class="longimgAlt d-none">' + obj.DBS_CardTile_LongTileImageAltText + '</p>',
        '<p class="shortimgPath d-none">' + obj.DBS_CardTile_ShortTileImagePath + '</p>',
        '<p class="shortimgAlt d-none">' + obj.DBS_CardTile_ShortTileImageAltText + '</p>',
        '<p class="subtitle d-none subtitle-">' + obj.DBS_CardTile_ShortDescription + '</p>',
        '<div class="card-tiles-footer">' + $(footerLabel).html(),
        '<p class="gray1-text"><span class="footerDate">' + obj.DBS_Publication_date + '</span>',
        '<span class="news-dot-right"> . </span><span class="footerMins">' + obj.DBS_Read_Duration + '</span> min read</p></div></div></a></div></div>'];
    }
    return tile;
}

function prepareFilterPagination(praramLists, resetPagination) {
    var filterList = eval(praramLists.filterListName);
    if (resetPagination) {
        reRenderPagination(praramLists);
    }
    preparePagination(filterList.matchingItems.length, praramLists);
    praramLists.itemContainer.find('.noResultContent').remove();
    if (filterList.matchingItems.length == 0) {
        praramLists.itemContainer.closest('.container').find('.card-tiles-desc').html('Displaying results 0 to 0 out of 0');
        praramLists.itemContainer.append('<div class="no-results mTop-32 noResultContent">No Results Found</div>');
    }
    else {
        praramLists.itemContainer.closest('.container').find('.card-tiles-desc').html('Displaying results ' + filterList.i + ' to ' + (filterList.i + filterList.visibleItems.length - 1) + '' + ' out of ' + filterList.matchingItems.length);
    }
}

function removeChip(target, multiSelect) {
    var listItemName = $(multiSelect).data('name');
    changed = true;
    var currIndex = target.attr("index");

    multiSelect
        .find(".countries-list")
        .find("li[index=" + currIndex + "]")
        .removeClass("hide");
    multiSelect
        .data("selectedListItems")
        .splice(
            multiSelect.data("selectedListItems").indexOf(multiSelectLists[listItemName][currIndex]),
            1
        );

    multiSelect.data("unselectedListItems").push(multiSelectLists[listItemName][currIndex]);
    multiSelect.data("unselectedListItems").sort();
    setView(null, multiSelect);


    selectOnchange($(multiSelect));

}

function setDropdownWidth() {
    //var inputWidth = $(".multiselect:first-child").innerWidth();
    $(".multiselect:visible").each(function (index) {
        var inputWidth = $(this).innerWidth();
        $(this)
            .find(".options")
            .css("width", inputWidth);

        setView("false", $(this));
    });
}

function resetSelect(thisElement, resetView) {
    $(thisElement).css('z-index', 'auto');
    $(thisElement)
        .find(".options")
        .hide();
    $(thisElement)
        .find(".input-wrapper")
        .removeClass("remove-border");
    $(thisElement)
        .find(".input-wrapper")
        .removeClass("show");
    $(".input-wrapper").find('.ico-cancel1').hide();
    if (resetView) {
        setView("false", $(thisElement));
    }

    $(thisElement)
        .find(".search")
        .val("")
        .trigger("keyup", thisElement);

    if (changed) {
        changed = false;
        //console.log(selectedList);
        //console.log('call ajax');
    }

    /*if ($(thisElement).data("selectedListItems").length) {
        //alert($(thisElement).data("selectedListItems"))
        //console.log('call ajax');
    }*/
}
// display
function setView(newExpandedView, multiSelect) {
    var listItemName = $(multiSelect).data('name');
    var selectedListItems = multiSelect.data("selectedListItems");
    expandedView = newExpandedView ? false : expandedView;
    if (selectedListItems && selectedListItems.length === 0) {
        multiSelect.find(".chips-container").removeClass("fill");
        multiSelect.find('.ico-cancel1').css('right', '35px');
    } else {
        // TODO: Add close icon
        multiSelect.find('.ico-cancel1').css('right', '10px');
        var chips = [];
        selectedListItems.forEach(function (d, i) {
            //console.log(d);
            chips.push(
                '<div class="basic-chip"><span class="chipText" title="' + d.itemLabel + '">' +
                d.itemLabel +
                "</span><span class='close-icon' index=" +
                multiSelectLists[listItemName].indexOf(d) +
                ">&#x2715;</span>" +
                "</div>"
            );
        });

        if (expandedView) {
            multiSelect.find(".chips-wrapper").html(chips);
            multiSelect.find(".chips-container").addClass("fill");
        } else {
            multiSelect.find(".chips-container").removeClass("pillsExpanded");
            multiSelect.find(".chips-wrapper").css('width', 'auto');
            var chip =
                '<div class="basic-chip"><span class="chipText" title="' + selectedListItems[0].itemLabel + '">' +
                selectedListItems[0].itemLabel +
                "</span><span class='close-icon' index=" +
                multiSelectLists[listItemName].indexOf(selectedListItems[0]) +
                ">&#x2715;</span>" +
                "</div>";
            multiSelect.find(".chips-wrapper").html(chip);
            multiSelect.find(".chips-container").addClass("fill");
        }

        var chipViewCount = 1;
        multiSelect.find(".counter-chip").remove();
        if (selectedListItems.length >= 2 && !expandedView) {
            while (selectedListItems.length > chipViewCount) {
                var chip =
                    '<div class="basic-chip"><span class="chipText" title="' + selectedListItems[chipViewCount].itemLabel + '">' +
                    selectedListItems[chipViewCount].itemLabel +
                    "</span><span class='close-icon' index=" +
                    multiSelectLists[listItemName].indexOf(selectedListItems[chipViewCount]) +
                    ">&#x2715;</span>" +
                    "</div>";
                multiSelect.find(".chips-wrapper").append(chip);
                chipViewCount = chipViewCount + 1;
                if (
                    multiSelect.find(".chips-wrapper").innerWidth() + 45 >
                    multiSelect.find(".chips").innerWidth()
                ) {
                    //console.log(multiSelect.find(".chips-wrapper").innerWidth());
                    //console.log(multiSelect.find(".chips").innerWidth());
                    //console.log($(multiSelect).find(".basic-chip:nth-child(" + chipViewCount + ")"));

                    $(multiSelect).find(".basic-chip:nth-child(" + chipViewCount + ")").remove();
                    chipViewCount = chipViewCount - 1;
                    break;
                }
            }

            if (selectedListItems.length > chipViewCount) {
                multiSelect
                    .find(".chips-wrapper")
                    .append("<div class='dots'>...</div>");
                multiSelect
                    .find(".chips-wrapper")
                    .append(
                        '<div class="counter-chip basic-chip">' +
                        (selectedListItems.length - chipViewCount) +
                        "</div>"
                    );
                multiSelect.find(".chips-container").removeClass("pillsExpanded");
                multiSelect.find(".chips-wrapper").css('width', '100%');
                // handle count chip click
                multiSelect.find(".counter-chip").on("click", function (e) {
                    expandedView = true;
                    multiSelect.find(".chips-wrapper").html(chips);
                    multiSelect.find(".chips-container").addClass("fill pillsExpanded");
                    multiSelect.find(".counter-chip").remove();
                    multiSelect.css('z-index', '999');
                    e.stopPropagation();
                });
            }
        }
    }
}

function filterListItems(multiSelect) {
    var thisInput = multiSelect.find('input');
    if (multiSelect.data('selectedListItems').length) {
        $(thisInput).closest('.inputContainer').find('.ico-cancel1').css('right', '10px');
    }
    else {
        $(thisInput).closest('.inputContainer').find('.ico-cancel1').css('right', '35px');
    }

    if ($(thisInput).val() !== '') {
        $(thisInput).closest('.inputContainer').find('.ico-cancel1').show();
    }
    else {
        $(thisInput).closest('.inputContainer').find('.ico-cancel1').hide();
    }

    var value = $(thisInput)
        .val()
        .toLowerCase();
    multiSelect.find(".options li").filter(function () {
        //console.log($(this).closest('.multiselect').data("unselectedListItems"));
        // console.log(multiSelect.data("unselectedListItems"));
        //console.log(multiSelect.data("unselectedListItems").indexOf($(this).text()) >= 0);
        //console.log('from include' + multiSelect.data("unselectedListItems").includes($(this).text()));

        var unselected = multiSelect.data("unselectedListItems").map(function (a) {
            return a.itemLabel.replace(/&amp;/g, "&");
        });

        if (
            $(this)
                .text()
                .toLowerCase()
                .indexOf(value) > -1 &&
            $.inArray($(this).text(), unselected) >= 0
        ) {
            $(this).removeClass("hide");
            // }
        } else {
            $(this).addClass("hide");
        }
    });
}
function selectOnchange(mutliselect) {
    var currentFilterGroup = "";
    if (mutliselect.data('name') == 'country') {
        currentFilterGroup = 'article';
        currentFilterName = 'country';
        incCountry = [];
        incCountryClass = [];

        mutliselect.data("selectedListItems").forEach(function (item) {
            // if checkbox, use value if checked
            incCountry.push(item.itemKey);
            incCountryClass.push('.' + item.itemKey);
            if (isEmpty(filtersBase)) {
                filtersBase = { 'type': 'country', 'value': item.itemKey };
            } else {
                if (filtersBase['type'] != 'country') {
                    if (isEmpty(filtersBase2)) {
                        filtersBase2 = { 'type': 'country', 'value': item.itemKey };
                    }
                }
            }
        });
    }
    if (mutliselect.data('name') == 'industry') {
        currentFilterGroup = 'article';
        currentFilterName = 'industry';
        incIndustry = [];
        incIndustryClass = [];
        mutliselect.data("selectedListItems").forEach(function (item) {
            // if checkbox, use value if checked
            incIndustry.push(item.itemKey);
            incIndustryClass.push('.' + item.itemKey);
            if (isEmpty(filtersBase)) {
                filtersBase = { 'type': 'industry', 'value': item.itemKey };
            } else {
                if (filtersBase['type'] != 'industry') {
                    if (isEmpty(filtersBase2)) {
                        filtersBase2 = { 'type': 'industry', 'value': item.itemKey };
                    }
                }
            }
        });

    }

    if (mutliselect.data('name') == 'socialcause') {
        currentFilterGroup = 'article';
        currentFilterName = 'socialcause';
        incSocialCause = [];
        incSocialCauseClass = [];
        mutliselect.data("selectedListItems").forEach(function (item) {
            // if checkbox, use value if checked
            incSocialCause.push(item.itemKey);
            incSocialCauseClass.push('.' + item.itemKey);
            if (isEmpty(filtersBase)) {
                filtersBase = { 'type': 'socialcause', 'value': item.itemKey };
            } else {
                if (filtersBase['type'] != 'socialcause') {
                    if (isEmpty(filtersBase2)) {
                        filtersBase2 = { 'type': 'socialcause', 'value': item.itemKey };
                    }
                }
            }
        });
    }

    if (mutliselect.data('name') == 'storyTopic') {
        currentFilterGroup = 'stories';
        currentFilterName = 'storyTopic';
        incStoryTopics = [];
        incStoryTopicsClass = [];
        mutliselect.data("selectedListItems").forEach(function (item) {
            // if checkbox, use value if checked
            incStoryTopics.push(item.itemKey);
            incStoryTopicsClass.push('.' + item.itemKey);
            if (isEmpty(storyFiltersBase)) {
                storyFiltersBase = { 'type': 'storyTopic', 'value': item.itemKey };
            } else {
                if (storyFiltersBase['type'] != 'storyTopic') {
                    if (isEmpty(storyFiltersBase2)) {
                        storyFiltersBase2 = { 'type': 'storyTopic', 'value': item.itemKey };
                    }
                }
            }
        });
    }

    if (mutliselect.data('name') == 'storyCategory') {
        currentFilterGroup = 'stories';
        currentFilterName = 'storyCategory';
        incStoryCategory = [];
        incStoryCategoryClass = [];
        mutliselect.data("selectedListItems").forEach(function (item) {
            // if checkbox, use value if checked
            incStoryCategory.push(item.itemKey);
            incStoryCategoryClass.push('.' + item.itemKey);
            if (isEmpty(storyFiltersBase)) {
                storyFiltersBase = { 'type': 'storyCategory', 'value': item.itemKey };
            } else {
                if (storyFiltersBase['type'] != 'storyCategory') {
                    if (isEmpty(storyFiltersBase2)) {
                        storyFiltersBase2 = { 'type': 'storyCategory', 'value': item.itemKey };
                    }
                }
            }
        });
    }

    if (currentFilterGroup == "article") {
        filtersRun(incCountry, incIndustry, incSocialCause);
        prepareFilterPagination(params.artileListParams, true);
        $('html, body').animate({
            scrollTop: $('#SED-article-list').closest('.container').offset().top - $('.header-placeholder').outerHeight()
        }, 1000);
    }
    if (currentFilterGroup == "stories") {
        storyFiltersRun(incStoryTopics, incStoryCategory);
        prepareFilterPagination(params.storyListParams, true);
        $('html, body').animate({
            scrollTop: $('#storyCards').closest('.container').offset().top - $('.header-placeholder').outerHeight()
        }, 1000);
    }
}

function multiselectInit(parentContainer) {
    selectedList = {};
    parentContainer.closest('.container').find(".multiselect").each(function (index) {
        var listItemName = $(this).data('name');
        // console.log(listItemName);
        $(this)
            .find(".options")
            .hide();
        var dupCountries = multiSelectLists[listItemName].slice(0);
        //var dupCountries = countries.slice(0);
        //console.log(dupCountries);

        $(this).data("selectedListItems", []);
        $(this).data("unselectedListItems", dupCountries);
        $(this).data("rawLists", dupCountries);
        var multiSelect = $(this);

        // Handle Search
        multiSelect.find(".search").on("keyup", function (e, outsideClick) {
            filterListItems(multiSelect);
        });

        multiSelect.find(".input-wrapper .close-icon").on("click", function (e) {
            var listItemName = $(multiSelect).data('name');
            var currIndex = $(this).attr("index");
            multiSelect
                .find(".countries-list")
                .find("li[index=" + currIndex + "]")
                .removeClass("hide");
            multiSelect
                .data("selectedListItems")
                .splice(
                    multiSelect.data("selectedListItems").indexOf(multiSelectLists[listItemName][currIndex]),
                    1
                );
            $(this)
                .parent()
                .remove();
            setView(null, multiSelect);
            // e.stopPropagation();
        });
        setCountries(multiSelect);
        /*if ($('.mobFilter').is(":visible")) {
            $(this).appendTo(".mobileFilterItem ." + listItemName);
        }*/
    });
}




///
function setCountries(multiSelect) {
    var listItemName = $(multiSelect).data('name');
    var options = '<ul class="countries-list">';
    multiSelectLists[listItemName].forEach(function (item, index) {
        var classNames = multiSelectLists.classNames[listItemName].find('#' + item.itemKey).attr('class');
        options += "<li index=" + index + " class='" + classNames + "'  data-key=" + item.itemKey + ">" + item.itemLabel + "</li>";
    });

    options += "</ul>";
    // setView(null, multiSelect);
    multiSelect
        .find(".options:first")
        .html(options)
        .find("li")
        .on("click", addSelectedItems);
}

// Add Country
function addSelectedItems(e) {
    var listItemName = $(e.target).closest(".multiselect").data('name');
    //console.log(multiSelectLists[listItemName]);
    changed = true;
    var index = $(this).attr("index");
    var currMultiSelect = $(this).closest(".multiselect");
    currMultiSelect.data("selectedListItems").push(multiSelectLists[listItemName][index]);
    $(this).addClass("hide");
    setView(null, $(this).closest(".multiselect"));
    currMultiSelect
        .data("unselectedListItems")
        .splice(
            currMultiSelect.data("unselectedListItems").indexOf(multiSelectLists[listItemName][index]),
            1
        );

    selectOnchange($(e.target).closest(".multiselect"));
}
