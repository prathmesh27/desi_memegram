$(document).ready(function() {
  /*	$.ajax({
			url: "news.json", 
			success: function(result){ 
			var htmlData = '';
			$.each(result, function(i, obj) { 
				
				htmlData +=  '<li><div class="news-title"><a href="'+obj["url"]+'">'+obj["news"]+'</a></div><div><span class="news-country">'+obj["country"]+'</span><span class="news-date"><span class="news-dot">.</span>'+obj["date"]+'</span></div></li>';
			});
			  $("#all-new-list").html(htmlData);
			 
			 var leftCountainerH = $(".news-left-block" ).outerHeight();
			var rightFirstCountainerH = $("#newsRightBlock" ).outerHeight(); 
			
			var rightHight = leftCountainerH - (15 + rightFirstCountainerH);
			// alert(leftCountainerH + "   " + rightFirstCountainerH + "   " + rightHight);
			 $("#viewAllNews").css("height", rightHight );
			 $("#viewAllNewsBox").css( "min-height", rightHight);
			 $("#imgViewAll").css("height", rightHight, "border-radius", "4px" ); 
			
	  }});*/

  var htmlData = "";
  var jsonData = JSON.parse($("#NewsJson").html());
  var result = jsonData.latestnews.news;
  $.each(result, function(i, obj) {
    var readDuration = "";
    if (obj["newsDuration"] != "") {
      readDuration =
        '<span class="news-dot">.</span>' + obj["newsDuration"] + " min read";
    }
    if (obj.hasOwnProperty("linkWord")) {
      var multiLangText = obj["linkWord"].split("##");
      var multiLangURL = obj["linkUrl"].split("##");
      var multiNews = "";

      if (multiLangText.length > 1) {
        $.each(multiLangText, function(ml_index, ml_value) {
          multiNews +=
            ' | <span><a href="/gsmc-grp/newsroom/' +
            multiLangURL[ml_index] +
            '">' +
            ml_value +
            "</a></span>";
        });
        if (multiNews.substring(multiNews.length - 1) == "|") {
          multiNews = multiNews.substring(0, multiNews.length - 1);
        }
        //multiNews = multiNews.substring(0, multiNews.length-1);

        htmlData +=
          '<li><div class="news-title"><a href="/gsmc-grp/newsroom/' +
          obj["NewsUrl"] +
          '">' +
          obj["title"] +
          "</a>" +
          multiNews +
          '</div><div><span class="news-country">' +
          obj["country"] +
          '</span><span class="news-date"><span class="news-dot">.</span>' +
          obj["date"] +
          readDuration +
          "</span></div></li>";
      } else {
        htmlData +=
          '<li><div class="news-title"><a href="/gsmc-grp/newsroom/' +
          obj["NewsUrl"] +
          '">' +
          obj["title"] +
          '</a> | <span><a href="/gsmc-grp/newsroom/' +
          obj["linkUrl"] +
          '">' +
          obj["linkWord"] +
          '</a></span></div><div><span class="news-country">' +
          obj["country"] +
          '</span><span class="news-date"><span class="news-dot">.</span>' +
          obj["date"] +
          readDuration +
          "</span></div></li>";
      }
    } else {
      htmlData +=
        '<li><div class="news-title"><a href="/gsmc-grp/newsroom/' +
        obj["NewsUrl"] +
        '">' +
        obj["title"] +
        '</a></div><div><span class="news-country">' +
        obj["country"] +
        '</span><span class="news-date"><span class="news-dot">.</span>' +
        obj["date"] +
        readDuration +
        "</span></div></li>";
    }
  });
  $("#all-new-list").html(htmlData);
  removeGSMCGroupURL();
});
