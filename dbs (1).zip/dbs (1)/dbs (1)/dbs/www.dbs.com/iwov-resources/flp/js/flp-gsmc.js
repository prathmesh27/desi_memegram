var orginalHTML = $("<div>");
var showMoreClicked = false;
var updatedData = "";
var directory = "";
var fiveStarAjaxURL = "";
var productName = "";
var binaryRatingAjaxURL = "";
var pollAjaxURL = "";

var paginationCurrentPage = 1;
var pagesStartFrom = 1;
var totalPages = 0;
var totalListCount = 0;
var currentCount = 0;
var startingRecord = 1;

var params = {};

//show hide trigger

if (window.IntersectionObserver) {
  $.event.special.visibility = {
    setup: function() {
      var element = this;
      var observer = new IntersectionObserver(
        function(entries) {
          var e = $.Event("visibility");
          e.visible = !!entries[0].intersectionRatio;
          ($.event.dispatch || $.event.handle).call(element, e);
        },
        {
          root: document.body
        }
      );
      observer.observe(element);
      $.data(this, "observer", observer);
    },
    teardown: function() {
      var observer = $.data(this, "observer");
      if (observer) {
        observer.unobserve(this);
        $.removeData(this, "observer");
      }
    }
  };
}

function removeGSMCGroupURL() {
  //remove the group from the url
  //console.log("Remove Class");
  // $("#testVisibility").removeClass("d-none");
  // $("#testVisibility").show();
  var akamaiLink =
    window.location.href.toLowerCase().indexOf("https://www") !== -1 ||
    window.location.href.toLowerCase().indexOf("http://www") !== -1 ||
    window.location.href.toLowerCase().indexOf("https://dbsweb-u01-www") !==
      -1 ||
    window.location.href.toLowerCase().indexOf("http://dbsweb-u01-www") !==
      -1 ||
    window.location.href.toLowerCase().indexOf("https://dbsweb-u02-www") !==
      -1 ||
    window.location.href.toLowerCase().indexOf("http://dbsweb-u02-www") !== -1;

  if (akamaiLink) {
    //remove group from meta og url
    var ogURL = $('meta[property="og:url"]').attr("content");
    if (ogURL) {
      ogURL = ogURL.replace("/sites/gsmc-grp", "");
      ogURL = ogURL.replace("/gsmc-grp", "");
      $('meta[property="og:url"]').attr("content", ogURL);
    }
    //remove group from meta twitter url
    var twitterURL = $('meta[name="twitter:url"]').attr("content");
    if (twitterURL) {
      twitterURL = twitterURL.replace("/sites/gsmc-grp", "");
      twitterURL = twitterURL.replace("/gsmc-grp", "");
      $('meta[name="twitter:url"]').attr("content", twitterURL);
    }

    $("a").each(function() {
      var hrefLink = $(this).attr("href");
      if (hrefLink) {
        hrefLink = hrefLink.replace("/sites/gsmc-grp", "");
        hrefLink = hrefLink.replace("/gsmc-grp", "");
        $(this).attr("href", hrefLink);
      }
    });
  }
}

(function($) {
  $(document).ready(function() {
    onDocumentReady();
  });
})(jQuery);

function onDocumentReady() {
  removeGSMCGroupURL();
  //fivestar rating xsl
  if ($(".article-star").length > 0) {
    $(".article-star").append($("#ratingHolder").html());
    $("#ratingHolder").remove();
    $.fiveStarInit(); //initialize fivestar logic
  }

  // article group
  if ($(".article-group").length > 0) {
    $(".navbar-box ul li").on("click", function() {
      $(this)
        .parent()
        .find("li")
        .removeClass("active");
      $(this).addClass("active");
    });
  }

  //promotion detail xsl
  if ($(".promotion-box.promotionDetail").length > 0) {
    $.promoSourceInit();
    $.tabOverflow();
    var faqCount = $("#faqCount").attr("data-value");
    for (var i = 1; i <= faqCount; i++) {
      $.collapseBoxInit("subCategory" + i);
    }
    $(".navbar-menu ul li").on("click", function() {
      $(this)
        .parent()
        .find("li.nav-item")
        .removeClass("active");
      $(this).addClass("active");
    });
    //add scroll for url section for tab
    if (window.location.hash) {
      var pgurl = window.location.href.substr(
        window.location.href.lastIndexOf("#") + 1
      );
      $(".tab-content .tab-pane").each(function() {
        if ($(this).prop("id") == pgurl) {
          $(this).addClass("active show");
        } else {
          $(this).removeClass("active show");
        }
      });
      $(".navbar-menu ul li a").each(function() {
        if ($(this).prop("href") == "#" + pgurl || $(this).prop("href") == "") {
          $(this).addClass("active show");
          //94 is a hardcode value, offset from the top menu
          $("html, body").animate(
            {
              scrollTop: $(this).offset().top - 150
            },
            1000
          );
        } else {
          $(this)
            .parent()
            .removeClass("active show");
        }
      });
    }
  }
  //contentlist xsl
  if ($(".contentList4B").length > 0) {
    $("body").addClass("graybg");
  }

  var navLinkHref = $(".breadcrumb li:eq(1) a").prop("href");
  if (navLinkHref != "") {
    $.hightlightMegaMenu(navLinkHref);
  }

  //viewmore text in mobile
  function myFunction(x) {
    console.log("inside viewmore");
    if (x.matches && !showMoreClicked) {
      // If media query matches
      if ($(orginalHTML).html() == "") {
        $(orginalHTML).append($(".viewMoreText").html());
      }
      $(".viewMoreText").html("");
      var prevLength = 0;
      $(orginalHTML)
        .children()
        .each(function() {
          var thisText = $(this).text();
          //console.log($(this).html());
          if (thisText.length + prevLength > 180) {
            $(".viewMoreText").append(
              $(this)
                .clone()
                .text(thisText.substring(0, 180 - prevLength) + "...")
            );
            $(".showMoreBtn").removeClass("d-none");
            return false;
          } else {
            $(".viewMoreText").append($(this).clone());
            $(".showMoreBtn").addClass("d-none");
          }
        });
    } else {
      if ($(orginalHTML).html() != "") {
        $(".viewMoreText").html("");
        $(".viewMoreText").append($(orginalHTML).clone());
        $(".showMoreBtn").addClass("d-none");
      }
      //console.log("notmatch")
    }
  }
  if ($(".viewMoreText").length) {
    var x = window.matchMedia("(max-width: 767px)");
    myFunction(x); // Call listener function at run time
    x.addListener(myFunction); // Attach listener function on state changes
  }
  $(".showMoreBtn a").bind("click", function() {
    showMoreClicked = true;
    $(".viewMoreText").html("");
    $(".showMoreBtn").addClass("d-none");
    $(".viewMoreText").append($(orginalHTML).html());
  });

  if ($("#cardCompareData").length > 0) {
    updatedData = $("#cardCompareData").text();
  }
  if ($("#toggleContext").length > 0) {
    directory = $("#toggleContext").attr("data");
    context_d = $("#toggleContext").attr("data");
  }

  if ($(".setColorCode").length > 0) {
    $(".card-tiles-footer, .card-footer, .media-body").each(function() {
      $(this)
        .find(".setColorCode")
        .css(
          "color",
          $(this)
            .find(".colorCode")
            .val()
        );
    });
  }

  /*if ($("#storyCards").length == 1) {
    //callAjaxRequestforUpdate();
    params.storyParams = {
      itemContainer: $(".story-card-container"),
      listItemName: "Story Cards",
      paginationCurrentPage: 1,
      pagesStartFrom: 1,
      totalPages: 0,
      totalListCount: 0,
      currentCount: $("#stories-pagination").data("currentcount"),
      startingRecord: 1
    };
    //currentCount = $("#stories-pagination").data("currentcount");
    preparePagination(
      $("#stories-pagination").data("totalrecords"),
      params.storyParams
    );
  }*/
  if ($("#newsLists").length == 1) {
    $("body").addClass("graybg");
    $("#newsCountryFilter").val("ALL");
    $("#mob-newsCountryFilter").val("ALL");
    $("#newsYearFilter").val("ALL");
    $("#mob-newsYearFilter").val("ALL");
    $("#newsMonthFilter").val("ALL");
    $("#mob-newsMonthFilter").val("ALL");
    //callAjaxRequestforUpdate();
    params.newsParams = {
      itemContainer: $(".news-list-container"),
      listItemName: "News Lists",
      paginationCurrentPage: 1,
      pagesStartFrom: 1,
      totalPages: 0,
      totalListCount: 0,
      currentCount: $("#newsListPagination").data("currentcount"),
      startingRecord: 1
    };
    //currentCount = $("#newsListPagination").data("currentcount");
    callAjaxRequestforUpdate(true, params.newsParams);
    /*preparePagination(
      $("#newsListPagination").data("totalrecords"),
      $(".news-list-container")
    );*/
  }
  if ($("#globalLocator").length) {
    initGlobalLocator();
  }

  $("#btnMobApplyFilterNews").on("touch click", function() {
    $(this)
      .closest(".filter-dropdown")
      .removeClass("show");
    $(this)
      .closest(".filter-menu")
      .removeClass("show");

    $("#newsCountryFilter").val($("#mob-newsCountryFilter").val());
    $("#newsYearFilter").val($("#mob-newsYearFilter").val());
    $("#newsMonthFilter").val($("#mob-newsMonthFilter").val());
    reRenderPagination(params.newsParams);
    //praramLists.url = $('#ajaxNewsListURL').val() + "?page=" + paginationCurrentPage + "&countryFilter=" + $('#newsCountryFilter').val() + "&monthFilter=" + $('#newsMonthFilter').val() + "&yearFilter=" + $('#mobnewsYearFilter').val();
    callAjaxRequestforUpdate("scroll", params.newsParams);
  });

  $("#btnClearFilterNews").on("touch click", function() {
    $(this)
      .closest(".filter-dropdown")
      .removeClass("show");
    $(this)
      .closest(".filter-menu")
      .removeClass("show");

    $("#newsCountryFilter").val("ALL");
    $("#mob-newsCountryFilter").val("ALL");
    $("#newsYearFilter").val("ALL");
    $("#mob-newsYearFilter").val("ALL");
    $("#newsMonthFilter").val("ALL");
    $("#mob-newsMonthFilter").val("ALL");

    reRenderPagination(params.newsParams);
    //praramLists.url = $('#ajaxNewsListURL').val() + "?page=" + paginationCurrentPage + "&countryFilter=" + $('#newsCountryFilter').val() + "&monthFilter=" + $('#newsMonthFilter').val() + "&yearFilter=" + $('#mobnewsYearFilter').val();
    callAjaxRequestforUpdate("scroll", params.newsParams);
  });
  $("#newsCountryFilter, #newsYearFilter, #newsMonthFilter").on(
    "change",
    function() {
      $("#mob-newsCountryFilter").val($("#newsCountryFilter").val());
      $("#mob-newsYearFilter").val($("#newsYearFilter").val());
      $("#mob-newsMonthFilter").val($("#newsMonthFilter").val());
      reRenderPagination(params.newsParams);
      callAjaxRequestforUpdate("scroll", params.newsParams);
    }
  );
  /*if ($("#bodywrapper .search-section").length == 1) {
    search_results_page = $("#search_results_data").attr("data-searchPage");
    $("body").addClass("graybg");
    context_s = $("#search_results_data").attr("data-contextS");
    context_d = $("#search_results_data").attr("data-contextD");
    search_gsa = "/iw/SearchBloxEntitySearch.jsp";
    search_results_page = search_results_page.replace(
      new RegExp("^" + "/" + context_s, "g"),
      "/" + context_d
    );
    var queryData = {
      q:
        $.getUrlParameters()["q"] === undefined
          ? $(".s-searchbox").val()
          : $.getUrlParameters()["q"],
      segment: window.location.pathname.substring(
        1,
        window.location.pathname.indexOf("/", 2)
      ),
      cat: "",
      start: "0"
    };
    $.initializeGSA(queryData);
  }*/
  jQuery(function($) {
    var _oldShow = $.fn.show;
    $.fn.show = function(speed, oldCallback) {
      return $(this).each(function() {
        var obj = $(this),
          newCallback = function() {
            if ($.isFunction(oldCallback)) {
              oldCallback.apply(obj);
            }
            obj.trigger("afterShow");
          };
        // you can trigger a before show if you want
        // obj.trigger('beforeShow');
        // now use the old function to show the element passing the new callback
        _oldShow.apply(obj, [speed, newCallback]);
      });
    };
  });
  jQuery(function($) {
    $("#bodywrapper")
      .bind("afterShow", function() {
        // alert('afterShow');
      })
      .show(1000, function() {
        if ($(".search-page").length == 1) {
          search_results_page = $("#search_results_data").attr(
            "data-searchPage"
          );
          $("body").addClass("graybg");
          context_s = $("#search_results_data").attr("data-contextS");
          context_d = $("#search_results_data").attr("data-contextD");
          search_gsa = "/iw/SearchBloxEntitySearch.jsp";
          search_results_page = search_results_page.replace(
            new RegExp("^" + "/" + context_s, "g"),
            "/" + context_d
          );
          var queryData = {
            q:
              $.getUrlParameters()["q"] === undefined
                ? $(".s-searchbox").val()
                : $.getUrlParameters()["q"],
            segment: window.location.pathname.substring(
              1,
              window.location.pathname.indexOf("/", 2)
            ),
            cat: "",
            start: "0"
          };
          $.initializeGSA(queryData);
        }

        if ($("#fiveStarAjaxURL").length > 0) {
          fiveStarAjaxURL = $("#fiveStarAjaxURL").attr("data-value");
        }
        if ($("#productName").length > 0) {
          productName = $("#productName").attr("data-value");
          if (productName != undefined && productName != "") {
            productName = productName.replace(/’/g, "'");
          }
        }
        if ($("#contentListAjaxURL").length > 0) {
          contentListAjaxURL = $("#contentListAjaxURL").attr("data-value");
        }
        if ($("#binaryRatingAjaxURL").length > 0) {
          binaryRatingAjaxURL = $("#binaryRatingAjaxURL").attr("data-value");
          if (binaryRatingAjaxURL.indexOf("/promotion/") != -1) {
            binaryRatingAjaxURL =
              binaryRatingAjaxURL.substring(
                0,
                binaryRatingAjaxURL.lastIndexOf("/")
              ) +
              ".page" +
              binaryRatingAjaxURL.substring(
                binaryRatingAjaxURL.lastIndexOf("/")
              );
          }
        }
        if ($("#pollAjaxURL").length > 0) {
          pollAjaxURL = $("#pollAjaxURL").attr("data-value");
        }
        //ArticleDetail xsl
        if ($(".ArtcleDetail4B").length > 0) {
          $.articleDetailInit();
          $.stickyNavigation(); //initialize sticky right navigation
        }
      })
      .show();
  });

  $("#sideNav").on("visibility", function(e) {
    if ($(".sticky-breadcrumb-in-mobile").length) {
      if (e.visible) {
        $(".breadcrumbContainer").css("margin-bottom", "0");
      } else {
        if (!$(".mobile-nav-bar").find(".breadcrumb").length) {
          $(".breadcrumbContainer")
            .find(".breadcrumb")
            .clone()
            .prependTo(".mobile-nav-bar");
        }
        var topMargin =
          $(".mobile-nav-bar").height() -
          $(".sticky-breadcrumb-in-mobile").height();
        if (topMargin < 0) {
          topMargin = 0;
        }
        $(".breadcrumbContainer").css("margin-bottom", topMargin);
      }
    }
  });

  $("#topicFilter, #catFilter").on("change", function() {
    reRenderPagination();
    callAjaxRequestforUpdate("scroll");
  });

  $("#geocodeInputFooter").on("focus", function() {
    console.log("New Test");
    window.initMap = function() {
      // Popup = createPopupClass();

      console.log("test");
      var searchBox1 = document.getElementById("geocodeInputFooter");
      autocomplete1 = new google.maps.places.Autocomplete(searchBox1);

      autocomplete1.addListener("place_changed", function() {
        var place = autocomplete1.getPlace();
        console.log("PLACE", place);
      });
    };
    if (typeof google == "undefined") {
      //var langValue = $("#data-lang").val() != '' ? $("#data-lang").val() : 'en';
      var newscript1 = document.createElement("script");
      newscript1.type = "text/javascript";
      newscript1.async = true;
      newscript1.src =
        "https://maps.googleapis.com/maps/api/js?libraries=geometry,places&client=gme-dbsbankltd&language=" +
        $("#data-lang").val() +
        "&callback=initMap";
      (
        document.getElementsByTagName("head")[0] ||
        document.getElementsByTagName("body")[0]
      ).appendChild(newscript1);
    }
  });

  $("#searchMenuId .button-wrapper, #mobileSlideId").on("click", function(
    event
  ) {
    $(".ss-gac-mm").css("display", "none");
    $.toggleBodyScrolling();

    $(".ss-gac-m").css("display", "none");
    $("#mobileSlideMenu .ss-gac-m").css("display", "none");

    setTimeout(function() {
      $("input.m-searchbox:visible").focus();
    }, 300);
  });
}

function initGlobalLocator() {
  /*var newscript = document.createElement("script");
  newscript.type = "text/javascript";
  newscript.async = true;
  newscript.src = "/iwov-resources/flp/js/global-locator.js";
  (
    document.getElementsByTagName("head")[0] ||
    document.getElementsByTagName("body")[0]
  ).appendChild(newscript);*/

  $("#globalLocator").load($("#globalLocator").data("url"), function() {
    var newscript = document.createElement("script");
    newscript.type = "text/javascript";
    newscript.async = true;
    newscript.src = $("#data-map").val();
    (
      document.getElementsByTagName("head")[0] ||
      document.getElementsByTagName("body")[0]
    ).appendChild(newscript);

    if (typeof google == "undefined") {
      //var langValue = $("#data-lang").val() != '' ? $("#data-lang").val() : 'en';
      var newscript = document.createElement("script");
      newscript.type = "text/javascript";
      newscript.async = true;
      newscript.src =
        "https://maps.googleapis.com/maps/api/js?libraries=geometry,places&client=gme-dbsbankltd&language=" +
        $("#data-lang").val() +
        "&callback=initMap";
      (
        document.getElementsByTagName("head")[0] ||
        document.getElementsByTagName("body")[0]
      ).appendChild(newscript);
    }

    setTimeout(function() {
      initloadMap(); //will trigger from global loacator js
    }, 1000);
  });
  /*if ($("#globalLocator").length == 1) {
    $.getScript("/iwov-resources/flp/js/global-locator.js", function(
      data,
      textStatus,
      jqxhr
    ) {
      if (typeof google == "undefined") {
        $.getScript(
          "https://maps.googleapis.com/maps/api/js?libraries=geometry,places&client=gme-dbsbankltd&language=en&callback=initMap",
          function(data, textStatus, jqxhr) {
            $("#globalLocator").load("global-locator.html", function() {
              setTimeout(function() {
                initloadMap(); //will trigger from global loacator js
              }, 200);
            });
          }
        );
      } else {
        $("#globalLocator").load("global-locator.html", function() {
          setTimeout(function() {
            initloadMap(); //will trigger from global loacator js
          }, 200);
        });
      }
    });
  }*/
}

function callAjaxRequestforUpdate(scrollRequired, praramLists) {
  praramLists.itemContainer.find(".loadSpinnerWrapper").show();
  praramLists.itemContainer.find(".loadSpinnerWrapper").offset({ left: 0 });
  praramLists.itemContainer.find(".loadSpinnerWrapper").width($window.width());

  if (praramLists.listItemName == "Story Cards") {
    praramLists.url =
      $("#ajaxStoriesURL").val() +
      "?page=" +
      praramLists.paginationCurrentPage +
      "&topicFilter=" +
      $("#topicFilter").val() +
      "&categoryFilter=" +
      $("#catFilter").val();
  } else if (praramLists.listItemName == "News Lists") {
    $(".sidebar-sticky").css("height", "auto");
    $("#noResultsNewsList").addClass("d-none");
    praramLists.url =
      $("#ajaxNewsListURL").val() +
      "?page=" +
      praramLists.paginationCurrentPage +
      "&countryFilter=" +
      $("#newsCountryFilter").val() +
      "&monthFilter=" +
      $("#newsMonthFilter").val() +
      "&yearFilter=" +
      $("#newsYearFilter").val();
  }

  console.log(praramLists.url);
  $.ajax({
    method: "GET", //for Akamai Caching for GET methods
    url: praramLists.url,
    cache: false,
    async: true,
    dataType: "xml",
    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
    crossDomain: true,
    success: function(responseText) {
      displayResult(responseText, praramLists);
      preparePagination(praramLists.totalListCount, praramLists);
      if (scrollRequired) {
        $("html, body").animate(
          {
            scrollTop:
              praramLists.itemContainer.offset().top -
              $(".header-placeholder").outerHeight()
          },
          1000
        );
      }
      praramLists.itemContainer.find(".loadSpinnerWrapper").hide();
    },
    error: function(xhr, textStatus, errorThrown) {
      praramLists.itemContainer.find(".loadSpinnerWrapper").hide();
      //console.log(xhr);
    },
    timeout: 60000 // 1hour timeout
  });
}

function displayResult(xmldata, praramLists) {
  if (praramLists.listItemName == "Story Cards") {
    $("#storyCards").html("");
    var longTile = $(
      '<div class="col-md-8 col-sm-6 col-xs-12 mmBtm-16">\n<div class="layout-box type8 same-side">\n<a target="_self" href="#">\n<div class="row only-image">\n<div class="type8-box1 col-sm-12 col-md-6 d-none d-md-block">\n<img class="img-fluid no-dynamic-js-handle onlywh-image" alt="" src="">\n</div>\n<div class="type8-box2 col-sm-12 col-md-6">\n<h4 class="story-title"></h4>\n<p class="sub-title"></p>\n<div class="card-tiles-footer">\n<p class="topicText bold-text"></p>\n<p class="gray1-text"><span class="footerDate"></span><span class="news-dot-right"> .\n</span><span class="footerMins"></span> min read</p>\n</div>\n</div>\n</div></a>\n</div>\n</div>'
    );
    var shortTile = $(
      '<div class="col-md-4 col-sm-6 col-xs-12">\n<div class="layout-box type7">\n<a target="_self" href="#">\n<div class="img-cover background-image-wrapper">\n<img class="img-fluid no-dynamic-js-handle" alt="" src="">\n</div>\n<div class="layout-plain">\n<h4 class="story-title"></h4>\n<div class="card-tiles-footer">\n<p class="topicText bold-text"></p>\n<p class="gray1-text"><span class="footerDate"></span><span class="news-dot-right"> .\n</span><span class="footerMins"></span> min read</p>\n</div>\n</div>\n</a>\n</div>\n</div>'
    );
    var shortTileCustom = $(
      '<div class="col-md-4 col-sm-6 col-xs-12 storyTile">\n<div class="layout-box type7">\n<a target="_self" href="">\n<div class="layout-plain">\n<h4 class="story-title pTop-16 mb-3"></h4>\n<p class="sub-title"></p>\n<div class="card-tiles-footer"><p class="topicText bold-text"></p><p class="gray1-text"><span class="footerDate"></span><span class="news-dot-right"> . </span><span class="footerMins"></span> min read</p></div>\n</div>\n</a>\n</div>\n</div>'
    );
    var jsonData = JSON.parse(
      $(xmldata)
        .find("storiesJSON")
        .text()
    );
    praramLists.totalListCount = jsonData.FilteredList.ListDetails.Total;
    praramLists.currentCount = 0;
    $.each(jsonData.FilteredList.CardTilesRow, function(i, row) {
      $.each(row.Tiles, function(i, item) {
        var tiles = "";
        var itemStory = item.TileContentType.Stories;
        console.log(item);
        if (!itemStory.Type) {
          return false;
        }
        praramLists.currentCount = praramLists.currentCount + 1;
        if (itemStory.TileType == "LONG_TILE") {
          tiles = longTile.clone();
          $(tiles)
            .find(".layout-box img")
            .attr("src", itemStory.DBS_CardTile_LongTileImagePath);
          $(tiles)
            .find(".layout-box img")
            .attr("alt", itemStory.DBS_CardTile_LongTileImageAltText);
          $(tiles)
            .find(".sub-title")
            .html(itemStory.DBS_CardTile_ShortDescription);
        } else if (itemStory.TileType == "SHORT_TILE_CUSTOM") {
          tiles = shortTileCustom.clone();
          $(tiles)
            .find(".sub-title")
            .html(itemStory.DBS_CardTile_ShortDescription);
        } else {
          tiles = shortTile.clone();
          $(tiles)
            .find(".layout-box img")
            .attr("src", itemStory.DBS_CardTile_ShortTileImagePath);
          $(tiles)
            .find(".layout-box img")
            .attr("alt", itemStory.DBS_CardTile_ShortTileImageAltText);
        }

        $(tiles)
          .find(".layout-box>a")
          .attr("href", itemStory.DBS_Stories_LinkURL);
        $(tiles)
          .find(".footerDate")
          .html(itemStory.DBS_Publication_date);
        $(tiles)
          .find(".footerMins")
          .html(itemStory.DBS_Read_Duration);
        $(tiles)
          .find(".topicText")
          .html(itemStory.DBS_Topic_Label)
          .css("color", itemStory.DBS_Topic_Color);
        $(tiles)
          .find(".story-title")
          .html(itemStory.DBS_CardTile_Title);
        $("#storyCards").append(tiles);
      });
    });
  }
  if (praramLists.listItemName == "News Lists") {
    $("#newsLists").html("");

    //var groupWrapper = $('<div class="news-list-group"><h3 class="mBot-24"></h3><ul></ul></div>');
    // var listItem = $('<li><a href=""><h3 class="h3-small mb-0"></h3></a><div><span class="news-country"></span><span class="news-dot">.</span><span class="news-date"></span></div></li>')
    var jsonData = JSON.parse(
      $(xmldata)
        .find("newsListJson")
        .text()
    );
    praramLists.totalListCount = jsonData.FilteredList.ListDetails.Total;
    if (!praramLists.totalListCount || praramLists.totalListCount == 0) {
      $("#noResultsNewsList").removeClass("d-none");
    }
    praramLists.currentCount = 0;
    $.each(jsonData.FilteredList.NewsLists, function(i, group) {
      var groupWrapper = $(
        '<div class="news-list-group"><h3 class="mBot-24"></h3><ul></ul></div>'
      );
      $(groupWrapper)
        .find("h3")
        .html(group.month);
      $.each(group.NewsItem, function(i, item) {
        var listItem = $(
          '<li><a href=""><h3 class="h3-small mb-0"></h3></a><div><span class="news-country"></span><span class="news-date"><span class="news-dot">.</span><span class="date"></span><span class="news-dot">.</span><span class="min-read">5</span></span></span></div></li>'
        );
        if (!item.News_Title) {
          return false;
        }
        praramLists.currentCount = praramLists.currentCount + 1;
        listItem.find("h3").html(item.News_Title);
        listItem.find("a").attr("href", "/gsmc-grp/newsroom/" + item.News_Link);
        listItem.find(".news-country").html(item.News_country);
        listItem.find(".date").html(item.News_date);
        if (!item.News_Read_Duration || item.News_Read_Duration == "") {
          listItem
            .find(".min-read")
            .prev(".news-dot")
            .hide();
          listItem.find(".min-read").hide();
        } else {
          listItem
            .find(".min-read")
            .html(item.News_Read_Duration + " min read");
        }
        if (item.Other_lang && item.Other_lang != "") {
          $.each(item.Other_lang, function(i, lang) {
            listItem
              .find("h3")
              .append(
                ' | <a href="/gsmc-grp/newsroom/' +
                  lang.other_lang_link +
                  '">' +
                  lang.other_lang_title +
                  "</a>"
              );
          });
        }
        $(groupWrapper)
          .find("ul")
          .append(listItem);
      });
      $("#newsLists").append(groupWrapper);
      $(".sidebar-sticky").height($(".news-list-container").height());
    });
  }
  removeGSMCGroupURL();
}

function preparePagination(totalRecards, praramLists) {
  var parentElement = praramLists.itemContainer;
  parentElement.find(".customPagination .pagination li").removeClass("current");
  parentElement.find(".customPagination .pagination").remove();

  praramLists.totalPages = totalRecards / 10;
  var additionalPage = 0;
  if (praramLists.totalPages % 1 !== 0) {
    additionalPage = 1;
  }
  praramLists.totalPages = parseInt(praramLists.totalPages + additionalPage);

  praramLists.startingRecord =
    totalRecards == 0 ? 0 : praramLists.paginationCurrentPage * 10 - 10 + 1;
  praramLists.currentCount =
    praramLists.paginationCurrentPage * 10 - 10 + praramLists.currentCount;

  //$('#storyCards').closest('.news-stories-card').find('.card-tiles-desc').text('Displaying results ' + startingRecord + ' to ' + currentCount + ' out of ' + totalRecards);
  parentElement
    .closest(".container")
    .find(".card-tiles-desc")
    .text(
      "Displaying results " +
        praramLists.startingRecord +
        " to " +
        praramLists.currentCount +
        " out of " +
        totalRecards
    );
  if (praramLists.totalPages == 1 || praramLists.totalPages == 0) {
    //$('#stories-pagination').hide();
    parentElement.find(".customPagination").hide();
    parentElement.find(".loadingSpinner").hide();
    return false;
  }
  var paginationWrapper = $(
    '<ul class="pagination d-none d-md-flex" role="menubar" aria-label="Pagination"></u>'
  );
  for (
    i = praramLists.pagesStartFrom;
    i <= praramLists.pagesStartFrom + 9;
    i++
  ) {
    if (i <= praramLists.totalPages) {
      var pageElement = $(
        '<li><a class="pageNum" data-page="' + i + '">' + i + "</a></li>"
      );
      if (
        i == praramLists.paginationCurrentPage ||
        (i == 1 && praramLists.paginationCurrentPage == 0)
      ) {
        $(pageElement).addClass("current");
      }
      $(paginationWrapper).append(pageElement);
    }
  }
  if (praramLists.paginationCurrentPage == 1) {
    //$('.pageNav.block1').addClass('disabled');
    parentElement
      .find(".customPagination .pageNav.block1")
      .addClass("disabled");
  }
  if (praramLists.paginationCurrentPage == praramLists.totalPages) {
    //$('.pageNav.block2').addClass('disabled');
    parentElement
      .find(".customPagination .pageNav.block2")
      .addClass("disabled");
  }
  if (praramLists.paginationCurrentPage < praramLists.totalPages) {
    $(paginationWrapper).append(
      '<li class="current"><a class="pageNav" data-step="+">&gt;</a></li>'
    );
  }
  if (praramLists.paginationCurrentPage > 1) {
    $(paginationWrapper).prepend(
      '<li class="current"><a class="pageNav" data-step="-">&lt;</a></li>'
    );
  }

  setTimeout(function() {
    parentElement.find(".customPagination").append(paginationWrapper);
    parentElement.find(".customPagination").show();
    parentElement.find(".loadingSpinner").hide();

    $(".pageNav")
      .unbind()
      .on("click", function() {
        console.log(praramLists.pagesStartFrom);
        //pagesStartFrom = 1;
        //alert(paginationCurrentPage);
        if ($(this).data("step") == "+") {
          if (praramLists.paginationCurrentPage == praramLists.totalPages) {
            return false;
          }
        }
        if ($(this).data("step") == "-") {
          if (praramLists.paginationCurrentPage == 1) {
            return false;
          }
        }
        //$('.pageNav').removeClass('disabled');
        $(this)
          .closest(".customPagination")
          .find(".pageNav")
          .removeClass("disabled");
        praramLists.paginationCurrentPage = eval(
          praramLists.paginationCurrentPage + $(this).data("step") + 1
        );

        if (
          praramLists.paginationCurrentPage % 10 >= 1 &&
          Math.floor(praramLists.paginationCurrentPage / 10) >= 1
        ) {
          praramLists.pagesStartFrom =
            Math.floor(praramLists.paginationCurrentPage / 10) * 10 + 1;
        } else {
          praramLists.pagesStartFrom =
            praramLists.pagesStartFrom > 10
              ? praramLists.pagesStartFrom - 10
              : 1;
        }
        //$('.pagination-block-mid').text('Page ' + paginationCurrentPage);
        $(this)
          .closest(".customPagination")
          .find(".pagination-block-mid")
          .text("Page " + praramLists.paginationCurrentPage);
        if (!$(this).closest(".no-dynamic-ajax-call").length) {
          callAjaxRequestforUpdate("scroll", praramLists);
        } else {
          eval(praramLists.filterListName).show(
            (praramLists.paginationCurrentPage - 1) * 10 + 1,
            10
          );
          prepareFilterPagination(praramLists, false);
          $("html, body").animate(
            {
              scrollTop:
                praramLists.itemContainer.closest(".container").offset().top -
                $(".header-placeholder").outerHeight()
            },
            1000
          );

          /* preparePagination(articleLists.matchingItems.length, praramLists);
           articleLists.show(praramLists.startingRecord, 10);
           $("#noResultsSEDList").remove();
           $("#SED-article-list")
             .closest(".container")
             .find(".card-tiles-desc")
             .html(
               "Displaying results " +
               articleLists.i +
               " to " +
               (articleLists.i + articleLists.visibleItems.length - 1) +
               "" +
               " out of " +
               articleLists.matchingItems.length
             );
           $("html, body").animate(
             {
               scrollTop:
                 $("#SED-article-list")
                   .closest(".container")
                   .offset().top - $(".header-placeholder").outerHeight()
             },
             1000
           );*/
        }
      });
    $(".pageNum")
      .not(".current .pageNum")
      .unbind()
      .on("click", function() {
        praramLists.paginationCurrentPage = $(this).data("page");
        $(this)
          .closest(".customPagination")
          .find(".pagination-block-mid")
          .text("Page " + praramLists.paginationCurrentPage);
        $(this)
          .closest(".customPagination")
          .find(".pageNav")
          .removeClass("disabled");
        if (!$(this).closest(".no-dynamic-ajax-call").length) {
          callAjaxRequestforUpdate("scroll", praramLists);
        } else {
          eval(praramLists.filterListName).show(
            (praramLists.paginationCurrentPage - 1) * 10 + 1,
            10
          );
          prepareFilterPagination(praramLists, false);
          $("html, body").animate(
            {
              scrollTop:
                praramLists.itemContainer.closest(".container").offset().top -
                $(".header-placeholder").outerHeight()
            },
            1000
          );
        }
      });
  }, 50);
}
function reRenderPagination(praramLists) {
  praramLists.paginationCurrentPage = 1;
  praramLists.pagesStartFrom = 1;
  praramLists.totalPages = 0;
  praramLists.currentCount = 0;
  praramLists.startingRecord = 1;
  praramLists.totalListCount = 0;
  $(".pagination-block-mid").text("Page " + praramLists.paginationCurrentPage);
  $(".pageNav").removeClass("disabled");
}

function changeNewsFilter() {
  $("#mob-newsCountryFilter").val($("#newsCountryFilter").val());
  $("#mob-newsYearFilter").val($("#newsYearFilter").val());
  $("#mob-newsMonthFilter").val($("#newsMonthFilter").val());
  reRenderPagination();
  //praramLists.url = $('#ajaxNewsListURL').val() + "?page=" + paginationCurrentPage + "&countryFilter=" + $('#newsCountryFilter').val() + "&monthFilter=" + $('#newsMonthFilter').val() + "&yearFilter=" + $('#newsYearFilter').val();
  callAjaxRequestforUpdate("scroll");
}

//Footer Script
var addthis_config = addthis_config || {};
addthis_config.data_track_addressbar = false;
addthis_config.data_track_clickback = false;

$.promoSourceInit = function() {
  $(".promoBtnHide").each(function() {
    $(this).hide();
  });
};

$("#language-toggle a").on("click", function() {
  var currhref = $(this).prop("href");
  if (currhref.indexOf("?") == -1) {
    currhref = $(this).prop("href") + location.search;
  }
  location.href = currhref;
});

/* Start Global footer search branch */

$(document).on("click", "#btnMainSearch", function(e) {
  var inputVal = $("#geocodeInputFooter").val();
  if (inputVal == "") {
    $("#geocodeInputFooter").focus();
  } else {
    window.open(
      "/gsmc-grp/Global_office_locator.page?s=true&q=" + inputVal + "",
      "_blank"
    );
  }
});

$("#geocodeInputFooter").focusout(function() {
  console.log("focusout111");
  if (navigator.userAgent.match(/(iPhone)/)) {
    var isChrome = typeof window.chrome === "object";
    if (
      navigator.userAgent.match("CriOS") &&
      Math.abs(window.orientation) === 90
    ) {
      var center = $(window).height() / 2;
      var top = $(this).offset().top;
      if (top > center) {
        $(window).scrollTop(top - center);
      }
    }
  }
});

/* End Global footer search branch */
