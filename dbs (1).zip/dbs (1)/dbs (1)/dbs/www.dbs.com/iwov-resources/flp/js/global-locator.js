var MARKER_ICON = "/iwov-resources/flp/images/maps-icons/POI_DBS_s.png";
var MARKER_ICON1 = "/iwov-resources/flp/images/maps-icons/POI_DBS_s.png";
var SOURCE_ICON =
  "https://chart.googleapis.com/chart?chst=d_map_pin_letter&chld=0|12AD2A|000000";
var map;
var markers = [];
var markersDetails = [];
var selectedCountryFilter = "All";
var selectedLat = "";
var selectedLng = "";
var INITIAL_ZOOM_VALUE = 10;
var prevOpenInfoWindow = -1;
var INITIAL_CENTER = {
  latitude: 1.33872,
  longitude: 103.70607
};
var showDirectionsButton = false;
var infoWindow1;

var countriesLocation = {
  Singapore: {
    latitude: 1.37052,
    longitude: 103.89425,
    zoom: 11
  },
  India: {
    latitude: 20.5937,
    longitude: 78.9629,
    zoom: 4
  },
  Indonesia: {
    latitude: 0.7893,
    longitude: 113.9213,
    zoom: 5
  },
  HongKong: {
    latitude: 22.3964,
    longitude: 114.1095,
    zoom: 8
  },
  China: {
    latitude: 39.913818,
    longitude: 116.363625,
    zoom: 4
  },
  Taiwan: {
    latitude: 23.6978,
    longitude: 120.9605,
    zoom: 7
  },
  UK: {
    latitude: 51.509865,
    longitude: -0.118092,
    zoom: 5
  },
  UAE: {
    latitude: 23.4241,
    longitude: 53.8478,
    zoom: 4
  },
  USA: {
    latitude: 41.4925,
    longitude: -100.9018,
    zoom: 3
  },
  Australia: {
    latitude: -25.2744,
    longitude: 133.7751,
    zoom: 4
  },
  Japan: {
    latitude: 36.2048,
    longitude: 138.2529,
    zoom: 6
  },
  Myanmar: {
    latitude: 21.9162,
    longitude: 95.956,
    zoom: 5
  },
  Korea: {
    latitude: 35.9078,
    longitude: 127.7669,
    zoom: 6
  },
  Philippines: {
    latitude: 12.8797,
    longitude: 121.774,
    zoom: 6
  },
  Thailand: {
    latitude: 15.87,
    longitude: 100.9925,
    zoom: 6
  },
  Vietnam: {
    latitude: 14.0583,
    longitude: 108.2772,
    zoom: 5
  },
  Malaysia: {
    latitude: 3.9457,
    longitude: 108.1429,
    zoom: 5
  },
  All: {
    latitude: 4.2105,
    longitude: 101.9758,
    zoom: 1
  }
};

var autocomplete = "";
var selectedBranchLatLng = "";
var directionsService = "";
var directionsDisplay = "";
var isPanoroma = false;
var infoWindows = [];
var anyPopUp = false;
zIndex = 100000;
var marker1;

var isMobileView = false;
var searchBox;
function layoutGoogleMap() {
  if (window.innerWidth < 746) {
    isMobileView = true;
    mobileView();
  } else {
    isMobileView = false;
    $("#googleMap")
      .removeClass("col-12")
      .addClass("col-8");
    $("#filter-wrapper")
      .removeClass("col-11")
      .addClass("col-4")
      .css({ height: "500" });
    $("#search-box , #search-icon").css({ display: "flex" });
    $("#mobile-search-icon").css({ display: "none" });
    $("#first-filter-wrapper").css({ width: "100%" });
    $("#locations-wrapper").removeClass("locations-margin");
    $("#locations-wrapper").css({ height: "calc(100% - 160px)" });
    // $("#complex-filter").css({ width: "auto" });
    $(".filter-row").css({ "flex-direction": "row" });
    $("#second-filter-wrapper").removeClass("second-filter-background");
    $("#mobile-close-icon").css({ display: "none" });
  }
  // displayLocations();
}

function mobileView() {
  $("#googleMap")
    .removeClass("col-8")
    .addClass("col-12");
  $("#filter-wrapper")
    .removeClass("col-4")
    .addClass("col-11")
    .css({
      height: "auto",
      margin: "auto"
    });
  $("#locations-wrapper").addClass("locations-margin");
  $("#locations-wrapper").css({ height: "120px" });

  // $("#complex-filter").css({ width: "calc(100% + 30px)" });
  $("#search-box , #search-icon").css({ display: "none" });
  $("#mobile-search-icon").css({ display: "flex", top: "8px" });
  $("#first-filter-wrapper").css({ width: "calc(100% - 60px)" });
  $("#mobile-close-icon").css({ display: "none" });

  $(".filter-row").css({ "flex-direction": "column" });
}
function getUrlParameter(name) {
  name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
  var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
  var results = regex.exec(location.search);
  return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};
var popup, Popup, popupHtml;

$(document).ready(function() {
  //branchList = branchList.filter(a=>a.type=="Branch");
 // console.log("branchList", branchList);

  var selectedBranch = getUrlParameter('q');
  if ($("#gl-standalone").length || (selectedBranch && selectedBranch != "" && selectedBranch != "undefined")) {
    initloadMap();
  }
  /*if (typeof google == "undefined") {
    $.getScript(
      "https://maps.googleapis.com/maps/api/js?libraries=geometry,places&client=gme-dbsbankltd&language=en&callback=initMap",
      function(data, textStatus, jqxhr) {
        console.log(data); // Data returned
        console.log(textStatus); // Success
        console.log(jqxhr.status); // 200
        setTimeout(function() {
          initloadMap(); //will trigger from global loacator js
        }, 200);
      }
    );
  }*/
  //initloadMap();
});

function initloadMap() {
  console.log("Load was performed.");
  var selectedBranch = getUrlParameter('q'); 

  //branchList = branchList.filter(a=>a.type=="Branch");
  branchList = $.grep(branchList, function (element, index) {
    return element.type == "office";
});
if ($(".splitter-main-container").length > 0) {  
  $("#splitter-visitus-heading").hide(); 
  $("#splitter-visitus-mTop0.mTop-32").css("margin-top", 0); 
  } 

  if(selectedBranch && selectedBranch != "" && selectedBranch != "undefined"){ 
      var country = selectedBranch.split(" ").pop();  
      $("#select-country").val('All'); 
      $("#search-box").val(selectedBranch); 
     calDistanceOnManualSearch(selectedBranch); 
     
}else{
  $("#select-country").val("All");
  
}




  //$("#select-country").val("All");
  $("#within-result").hide();
 
  layoutGoogleMap();
  directionsService = new google.maps.DirectionsService();
  directionsDisplay = new google.maps.DirectionsRenderer();
  myMap(INITIAL_ZOOM_VALUE, INITIAL_CENTER);

  filterMarkersBasedOnCountry(selectedCountryFilter);

  $("#select-country").on("change", function() {
    $("#search-box").val('');
    filterMarkersBasedOnCountry($("#select-country").val());
  });

  var width = $(window).width();
  $(window).on("resize", function() {
    if ($(this).width() != width) {
      layoutGoogleMap();
    }
  });

  $("#search-box").on("keyup", function() {
    if ($("#search-box").val() === "") {
      filterMarkersBasedOnCountry($("#select-country").val());
    }
  });
  /*console.log("insideinit");
  $.getScript($("#data-map").val(), function(data, textStatus, jqxhr) {
    console.log("Load was performed.");
    $("#within-result").hide();
    $("#select-country").val("All");
    layoutGoogleMap();
    directionsService = new google.maps.DirectionsService();
    directionsDisplay = new google.maps.DirectionsRenderer();
    myMap(INITIAL_ZOOM_VALUE, INITIAL_CENTER);

    filterMarkersBasedOnCountry(selectedCountryFilter);

    $("#select-country").on("change", function() {
      filterMarkersBasedOnCountry($("#select-country").val());
    });

    var width = $(window).width();
    $(window).on("resize", function() {
      if ($(this).width() != width) {
        layoutGoogleMap();
      }
    });

    $("#search-box").on("keyup", function() {
      if ($("#search-box").val() === "") {
        filterMarkersBasedOnCountry($("#select-country").val());
      }
    });
  });*/
  // google.maps.event.addDomListener(window, "load", initialize);
/*
  var marker1;
  if (window.orientation == undefined) {
    $("#locations-wrapper")
      .find(".location")
      .on("mouseenter", function(evt) {
        console.log("anyPopUp", anyPopUp);
        //evt.stopPropagation();
        if (anyPopUp == false) {
          setTimeout(function() {
            $(".gm-ui-hover-effect").css({ display: "none" });
          }, 50);

          var indVal = $(this)
            .closest(".location")
            .attr("index");

          var contentString =
            "<div id='popup-content'><h3>" +
            markersDetails[indVal].name +
            "</h3><p>" +
            markersDetails[indVal].address +
            "</p></div>";

          infoWindow1 = new google.maps.InfoWindow({
            content: contentString,
            maxWidth: 200
          });

          // console.log("AAAAA", markersDetails[0]);
          console.log(
            "markersDetails[indVal].type",
            markersDetails[indVal].type
          );
          var positions = {
            lat: markersDetails[indVal].latitude,
            lng: markersDetails[indVal].longitude
          };

          marker1 = new google.maps.Marker({
            position: positions,
            map: map,
            // visible: false,
            icon: MARKER_ICON1,
            //icon: serviceImages[markersDetails[indVal].type],
            pixelOffset: new google.maps.Size(0, -50)
          });

          marker1.setAnimation(google.maps.Animation.NONE);
          marker1.setZIndex(zIndex++);
          // anyPopUp = true;
          infoWindow1.open(map, marker1);
        }
      });
  }
*/
  




  $(document).on("click", ".gm-ui-hover-effect", function(e) {
    anyPopUp = false;
    $(".location").removeClass("selected-location-background");
  });

  //$("#mobile-search-icon").on("click", function() {
  $(document).on("click", "#mobile-search-icon", function(e) {
    e.preventDefault();  
    e.stopImmediatePropagation();
    $("#search-box").toggle();
    if ($("#search-box").length > 0) {
      $("#search-box").css({ "border-right": "1px solid #c0c0c0" });
      $("#mobile-search-icon").toggle();
      $("#mobile-close-icon").toggle();
      $("#second-filter-wrapper").addClass("second-filter-background");
      $("#filter-wrapper").css({ height: "auto" });
    }
  });

  //$("#mobile-close-icon").on("click", function() {
  $(document).on("click", "#mobile-close-icon", function(e) {
    $("#search-box").css({ display: "none" });
    $("#mobile-close-icon").css({ display: "none" });
    $("#mobile-search-icon").css({ display: "flex" });
    $("#second-filter-wrapper").toggleClass("second-filter-background");
    $("#filter-wrapper").css({ height: "auto" });
  });
}
//initloadMap();

window.initMap = function() {
  // Popup = createPopupClass();
  setTimeout(function() {
      /* Start Global footer search branch */
     
        console.log("test");
        var searchBox1 = document.getElementById("geocodeInputFooter");
        autocomplete1 = new google.maps.places.Autocomplete(searchBox1);
  
        autocomplete1.addListener("place_changed", function() {
          var place = autocomplete1.getPlace();
        console.log("PLACE", place); 
        
        });
       
    searchBox = document.getElementById("search-box");
    autocomplete = new google.maps.places.Autocomplete(searchBox);

    autocomplete.addListener("place_changed", function() {
      closeStreetView();
      var selectedBranch = getUrlParameter('q'); 
      if(selectedBranch && selectedBranch != "" && selectedBranch != "undefined"){
          var newPramas = $("#search-box").val();
          var completeUrl = window.location.href.split('?')[0];
         // window.location.href=''+completeUrl+'?q='+newPramas+'';
         //window.open(''+completeUrl+'?q='+newPramas+'', "_self");
         history.pushState(null, null, ''+completeUrl+'?q='+newPramas+'');
        
      } 
      var place = autocomplete.getPlace();

      if (Object.keys(place).length === 1) {
        calDistanceOnManualSearch(place.name);
        return;
      }

      if (!place) {
        noResult();
        return;
      }

      showDistanceResults(place);
    });
  }, 2000);
};

function sortBranchByName(array, key) {
  return array.sort(function(a, b) {
    var x = a[key].toLowerCase();
    var y = b[key].toLowerCase();
    return x < y ? -1 : x > y ? 1 : 0;
  });
}

function showDistanceResults(place) {
  hideMarkers();
  markers = [];
  markersDetails = [];
  infoWindows = [];

  /*
  branchList = branchList.filter(function(marker, index, self) {
    return (
      index ===
      self.findIndex(function(t) {
        return (
          t.latitude === marker.latitude && t.longitude === marker.longitude
        );
      })
    );
  });*/

  




  branchList = sortBranchByName(branchList, "name");

  for (i = 0; i < branchList.length; i++) {
    if (
      branchList[i].country === $("#select-country").val() ||
      $("#select-country").val() === "All"
    ) {
      selectedBranchLatLng = {
        latitude: place.geometry.location.lat(),
        longitude: place.geometry.location.lng()
      };
      var branchLatLng = {
        latitude: branchList[i].latitude,
        longitude: branchList[i].longitude
      };
      var distance = getDistance(selectedBranchLatLng, branchLatLng);
      if (distance <= 5) {
        showDirectionsButton = true;
        // markers.push(
        //   createMarker(branchList[i], MARKER_ICON, markers.length, false)
        // );
        let newObj =
          typeof branchList[i] === "object"
            ? Object.assign({}, branchList[i])
            : branchList[i];
        markersDetails.push(newObj);
        markersDetails[markersDetails.length - 1].distance = distance;
      }
    }
  }

  if (markersDetails.length > 0) {
    markersDetails.sort(function(a, b) {
      return a.distance > b.distance ? 1 : b.distance > a.distance ? -1 : 0;
    });

    for (i = 0; i < markersDetails.length; i++) { 
      markers.push(createMarker(markersDetails[i], MARKER_ICON, i, false));
    }
    var sourceMarkerDetails = {
      name: place.name,
      address: place.formatted_address,
      latitude: place.geometry.location.lat(),
      longitude: place.geometry.location.lng()
    };

    markers.push(
      createMarker(sourceMarkerDetails, SOURCE_ICON, markers.length, true)
    );

    zoomCountry(
      14,
      place.geometry.location.lat(),
      place.geometry.location.lng()
    );
    setMarkers();
    displayLocations();
    $("#within-result").show();
  } else {
    noResult();
  }
}

function calDistanceOnManualSearch(name) {
  var geocoder = new google.maps.Geocoder();

  geocoder.geocode({ address: name }, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      showDistanceResults(results[0]);
    }
  });
}

function handleOnClickSearchIcon() {
  google.maps.event.trigger(searchBox, "focus", {});
  google.maps.event.trigger(searchBox, "keydown", { keyCode: 13 });
}

function noResult() {
  if(infoWindow1){
    infoWindow1.close();
  }
  if(marker1){
    marker1.setVisible(false);
  }
  $("#locations-wrapper").html(
    "<p id='no-result'>" + $("#searchvalue").val() + "</p>"
  );
  $("#within-result").hide();
}

function closeStreetView() {
  if (isPanoroma) {
    panorama.setVisible(false);
    isPanoroma = false;
  }
  hideDirection();
}

function myMap(zoomValue, centerValue) {
  var mapProp = {
    center: new google.maps.LatLng(centerValue.latitude, centerValue.longitude),
    zoom: zoomValue
  };
  map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}

var markersDetailsToDisplay = [];
// var mobileViewIndex;
function displayLocations() {
  locationsHTML = "";
  // markersDetailsToDisplay = markersDetails.slice(0);
  // if (isMobileView) {
  //   markersDetailsToDisplay = markersDetails.slice(0, 1);
  //   mobileViewIndex = 0;
  //   if (index) {
  //     mobileViewIndex = index;
  //     markersDetailsToDisplay = [];
  //     markersDetailsToDisplay.push(markersDetails[index]);
  //   }
  // }

  markersDetails.forEach(function(marker, index) {
    locationsHTML +=
      "<div class='location' index=" +
      index +
      "><div><img class='location-marker' src=" +
      MARKER_ICON +
      "></div><div><h3>" +
      marker.name +
      "</h3>";

    if (marker.distance) {
      locationsHTML += "<p>(" + marker.distance + " km)</p>";
    }

    locationsHTML +=
      "<p>" + marker.address + "</p><p>" + marker.postal_code + "</p>";

    if (marker.tel) {
      locationsHTML +=
        "<p><img class='map-tel-icon' src='/iwov-resources/flp/images/maps-icons/ico_tel.png'>" +
        marker.tel +
        "</p>";
    }
    if (marker.fax) {
      locationsHTML +=
        "<p><img class='map-tel-icon' src='/iwov-resources/flp/images/maps-icons/ico_fax.png'>" +
        marker.fax +
        "</p>";
    }

    locationsHTML += "</div></div>";
  });

  $("#locations-wrapper").scrollTop(0);

  $("#locations-wrapper")
    .html(locationsHTML)
    .find(".location")
    .on("click", function() {
      if (infoWindow1) {
        infoWindow1.close();
      }
      closeStreetView();
      var markerIndex = $(this).attr("index");
      // if (isMobileView) {
      //   markerIndex = mobileViewIndex;
      // }

      $(".location").removeClass("selected-location-background");
      $(this).addClass("selected-location-background");
      zoomCountry(
        13,
        markersDetails[markerIndex].latitude,
        markersDetails[markerIndex].longitude
      );

      closeInfoWindow(prevOpenInfoWindow);
      anyPopUp = true;
      markers[markerIndex].setZIndex(zIndex++);
      infoWindows[markerIndex].open(map, markers[markerIndex]);
      setInfoWindowActions(markerIndex);
      prevOpenInfoWindow = markerIndex;
    });
    rightPanelHomer();
}

function closeInfoWindow(prevOpenInfoWindow) {
  if (prevOpenInfoWindow !== -1 && prevOpenInfoWindow < markers.length) {
    anyPopUp = false;
    infoWindows[prevOpenInfoWindow].close(map, markers[prevOpenInfoWindow]);
  }
}

function zoomCountry(zoomValue, lat, long) {
  map.setZoom(zoomValue);
  map.setCenter(new google.maps.LatLng(lat, long));
}

function filterMarkersBasedOnCountry(country) {
  $("#within-result").hide();
  closeStreetView();
  showDirectionsButton = false;
 // $("#search-box").val("");
  selectedCountryFilter = country;
  hideMarkers();
  markers = [];
  markersDetails = [];
  infoWindows = [];
  zoomCountry(
    countriesLocation[country].zoom,
    countriesLocation[country].latitude,
    countriesLocation[country].longitude
  );
  branchList = branchList.filter(function(marker, index, self) {
    return (
      index ===
      self.findIndex(function(t) {
        return (
          t.latitude === marker.latitude && t.longitude === marker.longitude
        );
      })
    );
  });
  branchList = sortBranchByName(branchList, "name");
  for (i = 0; i < branchList.length; i++) {
    if (branchList[i].country === country || country === "All") {
      let newObj =
        typeof branchList[i] === "object"
          ? Object.assign({}, branchList[i])
          : branchList[i];
      markers.push(createMarker(newObj, MARKER_ICON, markers.length, false));
      markersDetails.push(newObj);
    }
  }

  if (markers.length > 0) {
    setMarkers();
    displayLocations();
    
  } else {
    noResult();
  }
}

function hideMarkers() {
  for (i = 0; i < markers.length; i++) {
    putMarker(markers[i], null);
  }
}

function setMarkers() {
  for (i = 0; i < markers.length; i++) {
    putMarker(markers[i], map);
  }
}

function putMarker(marker, map) {
  marker.setMap(map);
}

function createMarker(markerDetail, markerIcon, index, isSourceMarker) {
  var latlng = new google.maps.LatLng(
    markerDetail.latitude,
    markerDetail.longitude
  );
  var marker = new google.maps.Marker({
    position: latlng,
    icon: markerIcon
    // title: markerDetail.name
  });

  marker.tooltipContent = "this content should go inside the tooltip";

  var infoHTML = '<div class="info-window-wrapper">';

  if (markerDetail.name) {
    infoHTML +=
      "<p style='margin-bottom: 1px;color: #000; font-weight:500'>" +
      markerDetail.name +
      "</p>";
  }

  infoHTML += "<p class='mBot-1'>" + markerDetail.address + "</p>";
  if (!isSourceMarker && markerDetail.postal_code) {
    if (markerDetail.tel != "" || markerDetail.fax != "") {
      infoHTML += "<p class='mBot-1'>" + markerDetail.postal_code + "</p>";
    } else {
      infoHTML += "<p >" + markerDetail.postal_code + "</p>";
    }
  }

  if (!isSourceMarker && markerDetail.tel) {
    if (markerDetail.fax != "") {
      infoHTML +=
        "<p class='mBot-1'><img class='map-tel-icon' src='/iwov-resources/flp/images/maps-icons/ico_tel.png'>" +
        markerDetail.tel +
        "</p>";
    } else {
      infoHTML +=
        "<p ><img class='map-tel-icon' src='/iwov-resources/flp/images/maps-icons/ico_tel.png'>" +
        markerDetail.tel +
        "</p>";
    }
  }
  if (!isSourceMarker && markerDetail.fax) {
    infoHTML +=
      "<p ><img class='map-tel-icon' src='/iwov-resources/flp/images/maps-icons/ico_fax.png'>" +
      markerDetail.fax +
      "</p>";
  }

  if (!isSourceMarker && markerDetail.operatingHours) {
    infoHTML += "<p >" + markerDetail.operatingHours + "</p>";
  }

  if (!isSourceMarker && markerDetail.SMSQ) {
    infoHTML +=
      "<p class='mBot-1 smsq' >SMS 'Q' to <span class='text-underline'>" +
      markerDetail.SMSQ +
      "</span></p><p>to request for a queue number</p>";
  }

  // "<p>" + markerDetail.tel + "</p>"

  if (!isSourceMarker) {
    infoHTML +=
      "<div style='width: 110%;margin: 20px 0 4px 0;'><button class='zoomBtn' index=" +
      index +
      ">" +
      $("#zoomvalue").val() +
      "</button>";
  }

  if (showDirectionsButton && !isSourceMarker) {
    infoHTML +=
      "<button class='directionsBtn' index=" +
      index +
      ">" +
      $("#directionvalue").val() +
      "</button>";
  }

  if (!isSourceMarker) {
    infoHTML +=
      "<button class='streetViewBtn' index=" +
      index +
      ">" +
      $("#streetvalue").val() +
      "</button>";
  }

  infoHTML += "</div>";

  var infoWindow = new google.maps.InfoWindow({
    content: infoHTML
  });

  google.maps.event.addListener(marker, "mouseover", function() {
    if (!infoWindows[index].getMap()) {
      /* marker.setAnimation(google.maps.Animation.BOUNCE);
      popupHtml =
        "<div id='popup-content'><h3>" +
        markersDetails[index].name +
        "</h3><p>" +
        markersDetails[index].address +
        "</p></div>";
      setPopUp(
        markersDetails[index].latitude + 10,
        markersDetails[index].longitude,
        map
      );*/
      if(anyPopUp == false){ 
      var contentString = "<div id='popup-content'><h3>" +
     markersDetails[index].name +
     "</h3><p>" +
     markersDetails[index].address +
     "</p></div>";

      window.infowindow = new google.maps.InfoWindow({
        content: contentString,
        maxWidth: 200
      });
      marker.setAnimation(google.maps.Animation.NONE);
      marker.setZIndex(zIndex++);
      window.infowindow.open(this.getMap(), this);
      setTimeout(function() {
        $(".gm-ui-hover-effect").css({ display: "none" });
      }, 50);
    }
  } 
  });

  google.maps.event.addListener(marker, "mouseout", function() {
    /*marker.setAnimation(null);
    if (popup) {
      popup.setMap(null);
    }*/
    infowindow.close();
    setTimeout(function () { 
    $(".gm-ui-hover-effect").css({ display: "block" });
    }, 50);
  });

  google.maps.event.addListener(marker, "click", function() {
    closeInfoWindow(prevOpenInfoWindow);
    anyPopUp = true;
    if(window.orientation ==undefined){
    if(infowindow){ 
      infowindow.close();
    }
  }
    infoWindow.open(map, marker);
    if (popup) {
      popup.setMap(null);
    }
    prevOpenInfoWindow = index;
    setInfoWindowActions(index);
    displayLocations(); /*
    if ($("#select-country").val() === "All" && $("#search-box").val() === "") {
      var currCountry = markersDetails[index].country;
      zoomCountry(
        countriesLocation[currCountry].zoom,
        countriesLocation[currCountry].latitude,
        countriesLocation[currCountry].longitude
      );
    }*/
  });

  infoWindows.push(infoWindow);
  rightPanelHomer();
  return marker;
}

function setPopUp(lat, lng, map) {
  Popup = createPopupClass();
  popup = new Popup(
    new google.maps.LatLng(lat, lng),
    document.getElementById("popup-content")
  );
  popup.setMap(map);
}

function setInfoWindowActions(index) {
  $("#googleMap").on(
    "click",
    ".directionsBtn[index=" + index + "]",
    function() {
      showDirection(
        {
          lat: parseFloat(markersDetails[index].latitude),
          lng: parseFloat(markersDetails[index].longitude)
        },
        {
          lat: selectedBranchLatLng.latitude,
          lng: selectedBranchLatLng.longitude
        }
      );
      anyPopUp = false;
      infoWindows[index].close(map, markers[index]);
    }
  );

  $("#googleMap").on(
    "click",
    ".streetViewBtn[index=" + index + "]",
    function() {
      showStreetView({
        lat: parseFloat(markersDetails[index].latitude),
        lng: parseFloat(markersDetails[index].longitude)
      });
      anyPopUp = false;
      infoWindows[index].close(map, markers[index]);
    }
  );

  $("#googleMap").on("click", ".zoomBtn[index=" + index + "]", function() {
    zoomCountry(
      15,
      markersDetails[index].latitude,
      markersDetails[index].longitude
    );
    //map.panBy(0,-100);
    anyPopUp = false;
    infoWindows[index].close(map, markers[index]);
  });

  $("#googleMap").on(
    "click",
    ".branchVideoBtn[index=" + index + "]",
    function() {
      $("#videoModal").modal("show");
      var videoHTML =
        "<iframe width='420' height='315' src='https://www.youtube.com/embed/Mri3rRjL8PU?autoplay=1'></iframe>";

      $("#video-modal-header").html(markersDetails[index].name);

      $("#video-body").html(videoHTML);

      $("#videoModal").on("hidden.bs.modal", function() {
        $("#videoModal iframe").attr("src", "");
      });
    }
  );
}

var panorama;
function showStreetView(latlng) {
  panorama = map.getStreetView();
  panorama.setPosition(latlng);
  panorama.setPov({
    heading: 265,
    pitch: 0
  });
  panorama.setVisible(true);
  isPanoroma = true;
}

function hideDirection() {
  directionsDisplay.setMap(null);
}

function showDirection(origin, destination) {
  directionsDisplay.setMap(map);
  directionsDisplay.setOptions({ suppressMarkers: true });

  directionsService.route(
    {
      origin: origin,
      destination: destination,
      travelMode: "DRIVING"
    },
    function(response, status) {
      if (status === "OK") {
        isDirections = true;
        directionsDisplay.setDirections(response);
      } else {
        window.alert("Directions request failed due to " + status);
      }
    }
  );
}

var rad = function(x) {
  return (x * Math.PI) / 180;
};

// distance between two points in google maps
function getDistance(p1, p2) {
  var R = 6378137; // Earth’s mean radius in meter
  var dLat = rad(p2.latitude - p1.latitude);
  var dLong = rad(p2.longitude - p1.longitude);
  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(rad(p1.latitude)) *
      Math.cos(rad(p2.latitude)) *
      Math.sin(dLong / 2) *
      Math.sin(dLong / 2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  // distance in meters
  var distance = R * c;
  // distance in km
  distance = distance / 1000;
  distance = Math.round(distance * 10) / 10;
  return distance;
}

function createPopupClass() {
  /**
   * A customized popup on the map.
   * @param {!google.maps.LatLng} position
   * @param {!Element} content The bubble div.
   * @constructor
   * @extends {google.maps.OverlayView}
   */
  function Popup(position, content) {
    this.position = position;

    var content = document.createElement("div");
    $(content).html(popupHtml);
    // if(content) {
    content.classList.add("popup-bubble");
    // }

    // This zero-height div is positioned at the bottom of the bubble.
    var bubbleAnchor = document.createElement("div");
    bubbleAnchor.classList.add("popup-bubble-anchor");
    bubbleAnchor.appendChild(content);

    // This zero-height div is positioned at the bottom of the tip.
    this.containerDiv = document.createElement("div");
    this.containerDiv.classList.add("popup-container");
    this.containerDiv.appendChild(bubbleAnchor);
    // Optionally stop clicks, etc., from bubbling up to the map.
    google.maps.OverlayView.preventMapHitsAndGesturesFrom(this.containerDiv);
  }
  // ES5 magic to extend google.maps.OverlayView.
  Popup.prototype = Object.create(google.maps.OverlayView.prototype);

  /** Called when the popup is added to the map. */
  Popup.prototype.onAdd = function() {
    this.getPanes().floatPane.appendChild(this.containerDiv);

    var bubbleHeight = $(".popup-bubble:first").innerHeight();
    var containerHeight = $(".popup-container:first").innerHeight();
    $(".popup-container:first").css({
      height: containerHeight + (bubbleHeight - 54) + "px"
    });
  };

  /** Called when the popup is removed from the map. */
  Popup.prototype.onRemove = function() {
    if (this.containerDiv.parentElement) {
      this.containerDiv.parentElement.removeChild(this.containerDiv);
    }
  };

  /** Called each frame when the popup needs to draw itself. */
  Popup.prototype.draw = function() {
    var divPosition = this.getProjection().fromLatLngToDivPixel(this.position);

    // Hide the popup when it is far out of view.
    var display = "block";
    if (display === "block") {
      this.containerDiv.style.left = divPosition.x + "px";
      this.containerDiv.style.top = divPosition.y + "px";
    }
    if (this.containerDiv.style.display !== display) {
      this.containerDiv.style.display = display;
    }
  };

  return Popup;
}


function rightPanelHomer(){
  

if(window.orientation ==undefined){

  $("#locations-wrapper").find('.location').on('mouseenter', function(evt) {
 console.log("anyPopUp" , anyPopUp); 
 //evt.stopPropagation(); 
 if(anyPopUp == false){
  setTimeout(function () { 
    $(".gm-ui-hover-effect").css({ display: "none" });
    }, 50);
  
  var indVal =  $(this).closest('.location').attr("index");
  
  var contentString = "<div id='popup-content'><h3>" +
  markersDetails[indVal].name +
  "</h3><p>" +
  markersDetails[indVal].address +
  "</p></div>";
 
    infoWindow1 = new google.maps.InfoWindow({
    content: contentString,
    maxWidth: 200
  });
  
 
 // console.log("AAAAA", markersDetails[0]);
 console.log("markersDetails[indVal].type", markersDetails[indVal].type);
  var positions = {lat: markersDetails[indVal].latitude, lng: markersDetails[indVal].longitude};
  
    marker1 = new google.maps.Marker({
    position: positions,
    map: map, 
   // visible: false,
     icon: MARKER_ICON1,
    //icon: serviceImages[markersDetails[indVal].type],
    pixelOffset: new google.maps.Size(0, -50) 
  }); 
   
  marker1.setAnimation(google.maps.Animation.NONE);
  marker1.setZIndex(zIndex++); 
 // anyPopUp = true;
 infoWindow1.open(map, marker1); 
 }
 
 });
 }
 
 
  
 
 //$("#locations-wrapper").on("mouseout", ".location", function(e) {
 $(document).on("mouseleave", "#locations-wrapper .location", function (e) { 
 // e.preventDefault();  
  // e.stopImmediatePropagation();
  if(infoWindow1){
    marker1.setVisible(false);
    infoWindow1.close();  
  }  
  // $(this).off('mouseleave');
 });
 
 
 
 $(document).on("click", ".gm-ui-hover-effect", function (e) {
  anyPopUp = false; 
  $(".location").removeClass("selected-location-background");
  
 });
}